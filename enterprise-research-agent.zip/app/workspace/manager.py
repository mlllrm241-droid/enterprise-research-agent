import json
import os

from datetime import datetime, timezone
from pathlib import Path
from typing import Any


class TaskWorkspace:
    """
    一个 Research Task 对应一个独立 Workspace。
    """

    def __init__(
        self,
        task_id: str,
        base_dir: str | None = None,
    ):
        workspace_root = (
            base_dir
            or os.getenv("WORKSPACE_ROOT", "workspace")
        )

        self.root = (
            Path(workspace_root)
            / "tasks"
            / task_id
        )

        self.task_id = task_id


    def create(
        self,
        user_query: str,
    ) -> None:
        """
        初始化任务工作目录。
        """

        self.root.mkdir(
            parents=True,
            exist_ok=True,
        )

        directories = [
            "research",
            "sources",
            "knowledge",
            "reviews",
            "final",
        ]

        for directory in directories:
            (
                self.root / directory
            ).mkdir(
                parents=True,
                exist_ok=True,
            )


        task_file = self.root / "task.json"

        if not task_file.exists():

            self.write_json(
                "task.json",
                {
                    "task_id": self.task_id,

                    "user_query": user_query,

                    "status": "created",

                    "created_at": datetime.now(
                        timezone.utc
                    ).isoformat(),

                    "updated_at": datetime.now(
                        timezone.utc
                    ).isoformat(),
                },
            )


    def _resolve_path(
        self,
        relative_path: str,
    ) -> Path:
        """
        获取 Workspace 内安全路径。
        """

        root = self.root.resolve()

        target = (
            self.root
            / relative_path
        ).resolve()


        if (
            target != root
            and root not in target.parents
        ):
            raise ValueError(
                "禁止访问 Workspace 之外的路径"
            )

        return target


    def write_text(
        self,
        relative_path: str,
        content: str,
    ) -> str:
        """
        写入文本 Artifact。
        """

        path = self._resolve_path(
            relative_path
        )

        path.parent.mkdir(
            parents=True,
            exist_ok=True,
        )

        path.write_text(
            content,
            encoding="utf-8",
        )

        return relative_path


    def read_text(
        self,
        relative_path: str,
    ) -> str:
        """
        读取文本 Artifact。
        """

        path = self._resolve_path(
            relative_path
        )

        return path.read_text(
            encoding="utf-8"
        )


    def write_json(
        self,
        relative_path: str,
        data: Any,
    ) -> str:
        """
        写入 JSON Artifact。
        """

        path = self._resolve_path(
            relative_path
        )

        path.parent.mkdir(
            parents=True,
            exist_ok=True,
        )

        path.write_text(
            json.dumps(
                data,
                ensure_ascii=False,
                indent=2,
            ),
            encoding="utf-8",
        )

        return relative_path


    def read_json(
        self,
        relative_path: str,
    ) -> Any:
        """
        读取 JSON Artifact。
        """

        content = self.read_text(
            relative_path
        )

        return json.loads(content)


    def get_path(self) -> str:
        """
        返回 Workspace 绝对路径。
        """

        return str(
            self.root.resolve()
        )


    def exists(
        self,
        relative_path: str,
    ) -> bool:
        """
        判断 Workspace Artifact 是否存在。
        """

        path = self._resolve_path(
            relative_path
        )

        return path.exists()