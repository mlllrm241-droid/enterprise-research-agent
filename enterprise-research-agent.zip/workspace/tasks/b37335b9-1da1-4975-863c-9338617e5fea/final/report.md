# NVIDIA 企业 AI 供应商研究与风险评估报告

**报告对象**：NVIDIA Corporation  
**研究期间**：最近一年，即 **2025年9月—2026年9月**  
**报告目的**：调研 NVIDIA 最近一年在企业 AI 领域的发展情况，并依据企业内部《AI Supplier Assessment Standard》评估其作为关键 AI 技术供应商在安全、业务连续性、财务风险和技术依赖风险方面的关注点。  
**证据规则**：公开事实使用对应 Source ID；企业内部标准使用 Knowledge Evidence ID。重要结论尽量追溯到证据；信息不足处单独说明。

---

## 1. 执行摘要

最近一年，NVIDIA 在企业 AI 领域的战略可以概括为：

> **硬件平台迭代 + 企业 AI 软件平台化 + 资本与生态绑定 + 全球主权 AI 扩张。**

其企业 AI 供应能力和市场主导地位显著增强，但从企业内部供应商评估标准看，NVIDIA 也暴露出若干需要重点管控的风险，尤其是 **技术依赖风险、业务连续性风险、出口管制合规风险和客户集中度风险**。

### 1.1 核心结论

| 维度 | 总体判断 | 主要依据 |
|---|---|---|
| 企业 AI 市场地位 | 显著领先，且从硬件向全栈平台扩展 | 数据中心市场份额、CUDA 生态、AI Factory 全栈产品、企业软件集成 [T01-S009][T03-S007][T03-S036][T02-S012] |
| 最近一年业务动作 | 积极扩张，资本绑定与生态锁定明显 | OpenAI、Anthropic、Intel、Groq、Mistral、SAP、ServiceNow、Cisco、Red Hat 等 [T01-S010][T01-S047][T01-S035][T01-S025][T01-S045][T01-S002][T01-S005][T01-S015] |
| 财务稳健性 | 自身财务实力强，短期破产/断供级风险低 | 收入、高毛利率、低长期债务、强现金回报 [T05-S053][T05-S055][T05-S046] |
| 财务结构性风险 | 中—高 | 数据中心收入占比极高、大客户集中、大客户资本开支可持续性存疑 [T05-S018][T05-S027][T05-S025][T05-S026] |
| 安全风险 | 中—低 | 安全认证和漏洞响应体系较完整，但合作伙伴环节发生数据泄露 [T04-S006][T04-S046][T04-S047][T04-S016][T04-S018] |
| 合规风险 | 中—高，且波动性高 | 出口管制政策反复，H20/H200 事件造成重大财务与区域可得性影响 [T04-S001][T04-S002][T04-S003][T05-S023] |
| 业务连续性风险 | 中—高 | DGX Cloud 依赖第三方云；先进封装、HBM、液冷、交付周期存在瓶颈 [T04-S041][T04-S042][T04-S014][T04-S015][T04-S037] |
| 技术依赖风险 | 高 | CUDA 生态锁定、NVLink/全栈绑定、替代方案短期不完全成熟、供应链与地缘可得性风险传导 [T05-S031][T05-S032][T05-S037][T05-S041][T05-S023] |

### 1.2 风险评级摘要

内部《AI Supplier Assessment Standard》未提供量化评分表，以下风险等级为基于标准要素的定性判断 [KB-D72727B32-C001]。

| 内部标准维度 | 风险等级 | 关键关注点 |
|---|---:|---|
| Security | 中—低 | 认证与漏洞响应较完整，但合作伙伴安全边界和检测延迟需关注 [T04-S006][T04-S016] |
| Compliance | 中—高 / 高波动 | 出口管制政策反复，涉华部署合法性与可得性存在先例 [T04-S001][T04-S002][T05-S023] |
| Business Continuity | 中—高 | 云服务依赖第三方云，硬件供应依赖 TSMC CoWoS、HBM 与液冷交付 [T04-S041][T04-S014][T04-S037] |
| Financial Risk | 综合中；自身偿债低，收入结构中高 | 收入高增长但高度集中于数据中心和少数大客户 [T05-S053][T05-S027][T05-S026] |
| Technology Dependency | 高 | CUDA、NVLink、AI Enterprise/NIM/NeMo 等形成深度生态锁定 [T05-S031][T05-S032][T03-S022] |

---

## 2. 评估依据：内部标准与报告标准

### 2.1 企业内部供应商评估标准

企业内部《AI Supplier Assessment Standard》要求评估以下维度 [KB-D72727B32-C001]：

1. **Security**：供应商应提供数据存储、数据隔离、访问控制、安全事件响应和模型使用政策的明确信息。  
2. **Compliance**：供应商应识别适用的隐私、安全和监管义务。  
3. **Business Continuity**：关键供应商应提供服务可用性、灾难恢复和重大服务依赖风险信息。  
4. **Financial Risk**：应评估收入稳定性、客户集中度、重大资本需求及影响长期服务连续性的因素。  
5. **Technology Dependency**：应评估对关键硬件、云平台、第三方软件和外部供应链的依赖。

### 2.2 企业内部研究报告标准

企业内部《Enterprise Research Report Standard》要求完整企业研究报告覆盖公司背景、主要产品与服务、近期重大业务发展、竞争格局、财务信息、重大经营与运营风险，并为重要结论提供可追溯证据 [KB-D10D9F4B2-C001]。

### 2.3 公开事实与内部标准的区分

- **内部标准**仅定义评估框架，不构成 NVIDIA 事实证据 [KB-D72727B32-C001]。
- **公开事实**来自外部研究 Artifact 和 Source Index，用于证明 NVIDIA 的实际表现、产品、竞争与风险状况。
- 当公开信息存在不同口径或第三方估算时，本报告明确标注不确定性。

---

## 3. 公司概况与最近一年财务/市场表现

### 3.1 公司定位

NVIDIA 自我定位为“AI 和加速计算领域全球领导者”，其企业 AI 战略正从销售 GPU 转向构建“AI Factory”全栈基础设施 [T01-S003][T02-S012][T02-S036]。

在 2024 年 AI 数据中心市场中，NVIDIA 以超过 20% 的市场份额居首；前七大公司合计占约 48% [T01-S009]。在 AI 加速器/训练市场，NVIDIA 仍保持高份额，公开来源口径包括约 80% 训练收入份额、约 80% 加速器份额、约 86% AI GPU 份额等 [T03-S007][T03-S037][T03-S036]。

### 3.2 最近一年财务表现

NVIDIA 最近一年财务表现极其强劲：

| 指标 | 数据 | 证据 |
|---|---:|---|
| FY2026 全年收入 | 2,159 亿美元，同比 +65% | [T05-S053][T05-S055][T05-S007] |
| FY2026 Q4 单季收入 | 681 亿美元，同比 +73% | [T05-S053][T05-S055] |
| FY2026 Q4 数据中心收入 | 623 亿美元 | [T05-S055][T03-S068] |
| FY2026 GAAP 毛利率 | 71.1% | [T05-S053][T05-S055] |
| FY2026 GAAP 摊薄 EPS | 4.90 美元 | [T05-S053][T05-S055] |
| FY2026 股东回报 | 411 亿美元回购+分红 | [T05-S053][T05-S055] |
| FY2027 Q1 收入 | 816 亿美元，同比 +85% | [T05-S052][T05-S015] |
| FY2027 Q2 收入 | 962 亿美元，同比 +106% | [T05-S016][T05-S018] |
| FY2027 Q2 数据中心收入 | 890 亿美元，同比 +117%，占总收入约 92.5% | [T05-S016][T05-S018] |
| FY2027 Q3 指引 | 约 1,080 亿美元，且指引中不含中国数据中心计算收入 | [T05-S018] |
| 长期债务 | 约 74.69 亿美元，截至 2026-01-25 | [T05-S046] |
| 市值 | 约 5.2 万亿美元，2026年8月口径 | [T05-S017] |

**判断**：NVIDIA 自身财务稳健性很强，短期“供应商破产/断供级”财务风险低。但其收入高度集中于数据中心/AI 算力业务，且大客户集中度高，构成结构性财务风险 [T05-S018][T05-S027][T05-S026]。

---

## 4. 最近一年企业 AI 领域重要业务动作

本章覆盖 2025年9月至2026年9月期间的重要业务动作，包括投资并购、产品发布、企业合作、生态建设和主权 AI 布局。

### 4.1 重大投资、并购与资本绑定

#### 4.1.1 投资 Intel 并联合开发 x86 AI 芯片

- **时间**：2025-09-18 宣布；2025-12-26 交割。  
- **内容**：NVIDIA 向 Intel 投资 50 亿美元，购入约 2.148 亿股，每股 23.28 美元，约 4% 股份。双方达成战略合作：Intel 为 NVIDIA AI 基础设施定制 x86 CPU，并开发集成 NVIDIA RTX GPU chiplet 的 PC SoC，通过 NVLink 互联，NVLink 带宽可达 1.8 TB/s。  
- **业务线**：数据中心、CPU、PC 生态。  
- **影响**：NVIDIA 打通 x86 生态入口，降低企业迁移门槛；同时扩展至 CPU 层，但也引发类似当年 Arm 收购案的监管关注。  
- **证据**：[T01-S035][T01-S036][T01-S037][T01-S038][T01-S039]

#### 4.1.2 与 OpenAI 达成 10 吉瓦战略合作

- **时间**：2025-09-22。  
- **内容**：OpenAI 将部署至少 10 吉瓦 NVIDIA 系统；NVIDIA 随每吉瓦部署逐步投资最高 1,000 亿美元；首个吉瓦预计 2026 年下半年通过 Vera Rubin 平台上线。  
- **业务线**：数据中心系统、云服务基础设施。  
- **影响**：锁定全球头部 AI 模型厂商的长期算力需求，巩固 NVIDIA 在超大规模 AI 基础设施中的核心供应地位。  
- **证据**：[T01-S010]

#### 4.1.3 投资 Anthropic，并与 Microsoft 形成三方合作

- **时间**：2025-11-18。  
- **内容**：Microsoft、NVIDIA、Anthropic 宣布战略合作。NVIDIA 承诺向 Anthropic 投资最高 100 亿美元，Microsoft 最高 50 亿美元；Anthropic 承诺购买 300 亿美元 Azure 算力，并签约最多 1 吉瓦基于 NVIDIA Grace Blackwell 和 Vera Rubin 系统的算力。  
- **业务线**：模型生态、数据中心系统、Azure 渠道。  
- **影响**：将主要前沿模型厂商绑定至 NVIDIA 硬件与 Azure 渠道，强化企业客户通过 Azure 获取 Claude 的路径。  
- **证据**：[T01-S047][T01-S048][T01-S049][T01-S050][T01-S051]

#### 4.1.4 Groq 技术授权交易：NVIDIA 史上最大交易

- **时间**：2025-12-24 宣布。  
- **内容**：NVIDIA 与推理芯片初创公司 Groq 达成约 200 亿美元的非独占技术授权协议，获得其 LPU 推理技术 IP 授权，并招募包括创始人 CEO Jonathan Ross、总裁 Sunny Madra 在内约 90% 的 Groq 员工；Groq 公司本体及 GroqCloud 保持独立运营。约 85% 款项预付，其余分 2026 年中与年底支付。  
- **业务线**：AI 推理、数据中心架构。  
- **影响**：NVIDIA 计划将 Groq 低延迟处理器整合进 AI Factory 架构，补齐实时推理短板，并消除潜在竞争对手。  
- **监管风险**：2026年3月，美国参议员 Warren 和 Blumenthal 就该交易是否规避并购审查、违反反垄断法展开质询。  
- **证据**：[T01-S025][T01-S026][T01-S027][T01-S028][T01-S029]

#### 4.1.5 其他战略投资

| 对象 | 内容 | 证据 |
|---|---|---|
| Synopsys | NVIDIA 投资 20 亿美元，达成多年合作，Synopsys 使用 NVIDIA 技术开发 EDA 软件 | [T01-S018] |
| Mistral AI | 参与其 2025年9月 17 亿欧元 C 轮融资；2026年3月进一步约定在 Nemotron 联盟下联合开发前沿开源模型 | [T01-S045] |
| xAI / SpaceX | 监管文件显示 NVIDIA 通过 xAI 投资持有约 210 亿美元 SpaceX 权益 | [T01-S016] |
| AI 全产业链投资 | NVIDIA 以战略投资者身份贯穿模型厂、neocloud、芯片、EDA 等环节，强化生态控制力，但也引发“循环融资”质疑 | [T01-S017] |

**综合判断**：NVIDIA 正通过资本绑定巩固需求侧与供给侧生态，但也积累反垄断审查、客户集中和循环交易质疑等风险信号 [T01-S017][T01-S025][T01-S039]。

---

### 4.2 产品与平台发布动作

#### 4.2.1 GTC Washington D.C.：6G AI-RAN 与本土制造

- **时间**：2025-10-28。  
- **内容**：发布 6G AI-RAN 全栈方案；强调 NVIDIA 已成为开源 AI 模型/数据/工具第一大贡献者；黄仁勋宣布最快 AI 芯片已在美国亚利桑那州生产。  
- **业务线**：网络/电信、供应链本土化。  
- **影响**：拓展电信企业 AI 场景；美国本土制造有助于降低部分地缘供应链风险。  
- **证据**：[T01-S021][T01-S022]

#### 4.2.2 GTC 2026 圣何塞：企业 AI 代理平台与 Vera Rubin

- **时间**：2026-03-16 至 2026-03-19。  
- **核心发布**：

| 产品/平台 | 内容 | 证据 |
|---|---|---|
| Vera Rubin 平台 | 集成 CPU、GPU、网络、存储的 AI 基础设施系统，面向 AI Factory；官方口径 2026 下半年发货接棒 GB200/GB300 | [T01-S006][T01-S008][T02-S033][T02-S034] |
| Vera CPU | 专为 AI 代理工作负载和强化学习设计的处理器 | [T01-S006] |
| Agent Toolkit / OpenShell / NemoClaw / Nemotron | 企业 AI 代理软件栈：开源 Agent Toolkit、OpenShell 运行时、NemoClaw 架构、Nemotron 模型系列 | [T01-S006][T01-S043][T01-S042] |
| RTX PRO 4500 Blackwell Server GPU | 165 瓦单插槽，面向企业数据中心节能部署；存储合作伙伴包括 Dell、IBM、NetApp、Hitachi Vantara、WEKA 等 | [T01-S007] |
| Vera Rubin DSX AI Factory 参考设计 | 企业可先在软件中模拟 AI 工厂，再物理建造 | [T01-S007] |
| Feynman 下一代路线图 | 包括 Rosa LPU LP40 与 BlueField-5 等 | [T01-S007] |

- **影响**：标志 NVIDIA 从“卖芯片”转向“拥有 AI 代理时代的平台层”，覆盖硬件、运行时、模型、企业工作流全栈 [T01-S004]。

#### 4.2.3 GTC Taipei / COMPUTEX：Agent 能力下沉至 PC 与物理世界

- **时间**：2026-06-01 至 2026-06-04。  
- **内容**：发布 Nemotron 3 Ultra 开放模型、DSX AI Factory、RTX Spark AI PC、Cosmos 3 物理 AI 模型、Isaac GR00T 机器人平台；Vera Rubin NVL72 获 COMPUTEX “Best Choice of the Year”。黄仁勋宣布 AI 进入 “Agentic 时代”，并强调台湾供应链拥有 150 家伙伴、350+ 工厂。  
- **业务线**：模型、AI PC、机器人、供应链。  
- **影响**：将 Agent 能力从数据中心下沉至企业 PC 与物理世界，形成“数据中心—桌面—物理世界”闭环。  
- **证据**：[T01-S040][T01-S041][T01-S042][T01-S002][T01-S008]

---

### 4.3 企业软件巨头集成与生态建设

#### 4.3.1 企业软件平台集成

| 合作伙伴 | 内容 | 证据 |
|---|---|---|
| SAP | 将 OpenShell 嵌入 Joule Studio 运行时；NIM 微服务在 SAP AI Core 中推理性能提升最高 20% | [T01-S002][T01-S013] |
| ServiceNow | 将智能工作流与 NVIDIA Enterprise AI Factory 验证设计整合；企业自主桌面代理 Project Arc 采用 OpenShell 实现策略化安全管理 | [T01-S001][T01-S002] |
| Adobe、Salesforce 等 17 家企业 | 成为企业 AI 代理平台首批采用者 | [T01-S004] |
| AWS、Google Cloud、Microsoft Azure、Oracle Cloud 及 Cisco、Dell、HPE、Lenovo、Supermicro | 支持在其基础设施上构建和运行 NVIDIA AI 代理 | [T01-S003] |

**影响**：NVIDIA 软件栈深度嵌入全球主流企业应用平台，显著提升企业客户粘性与切换成本 [T01-S002][T01-S004][T01-S013]。

#### 4.3.2 基础设施与云伙伴扩展

| 合作伙伴 | 动作 | 证据 |
|---|---|---|
| Cisco | 推出首款基于 NVIDIA Spectrum-X 以太网交换芯片的合作伙伴数据中心交换机 N9100；Cisco Secure AI Factory 增强安全与可观测能力 | [T01-S005] |
| Red Hat | 与 NVIDIA 联合打造 AI 工厂协同工程软件平台；Cisco Secure AI Factory 支持 Red Hat AI Factory 软件 | [T01-S015] |
| NTT DATA | 推出 NVIDIA 驱动的企业 AI 工厂全栈方案，整合 NVIDIA AI Enterprise、NIM 与 NeMo | [T01-S014] |
| Supermicro | 发布 7 套基于 NVIDIA 参考架构的 AI 数据平台方案 | [T01-S011] |
| Dell | Dell AI Factory 成为 Dell 关键收入驱动，Dell AI 订单 244 亿美元、AI 服务器积压订单创纪录 513 亿美元 | [T01-S012] |
| HPE | 扩展面向政府、受监管行业和企业的 NVIDIA AI Computing by HPE 组合 | [T02-S011] |

**影响**：NVIDIA 形成覆盖云、服务器、网络、软件的多层分发网络，企业 AI 供应能力高度依赖 NVIDIA 生态 [T01-S003][T01-S005][T01-S014][T01-S015]。

---

### 4.4 主权 AI 与区域数据中心布局

| 项目 | 内容 | 证据 |
|---|---|---|
| Deutsche Telekom | 与 NVIDIA 投资 10 亿欧元建设慕尼黑 AI 数据中心，部署 1 万块最新一代 NVIDIA GPU，算力约 0.5 exaflops；公开来源对投运状态表述略有差异 | [T01-S046][T01-S044] |
| Mistral Compute | 基于 18,000 块 NVIDIA Grace Blackwell 系统的法国主权 AI 云；2026年3月 Mistral 新数据中心将部署 13,800 块 GB300 | [T01-S045][T01-S044] |
| Stargate 生态 | NVIDIA 参与 Stargate 项目 4 年 5,000 亿美元承诺；多个站点部署 NVIDIA 系统 | [T01-S009][T01-S030][T01-S031] |
| Stargate UK | 存在落地不确定性，OpenAI 曾搁置相关英国项目 | [T01-S034] |

**影响**：NVIDIA 抓住欧洲主权 AI 需求，将企业级部署从美国扩展至全球，同时降低单一市场集中度；但部分大型项目存在落地不确定性 [T01-S045][T01-S046][T01-S034]。

---

### 4.5 最近一年业务动作综合影响

| 维度 | 判断 | 证据 |
|---|---|---|
| 市场地位 | 持续强化，AI 数据中心市场领先 | [T01-S009] |
| 供应能力 | Vera Rubin 2026H2 量产/发货、亚利桑那制造、10GW 级订单锁定提升产能与交付确定性，但第三方仍提示 Rubin 延迟风险 | [T01-S008][T01-S022][T01-S010][T04-S037] |
| 生态锁定 | 从硬件扩展至软件平台层，SAP、ServiceNow、Adobe、Salesforce 等深度集成，切换成本上升 | [T01-S002][T01-S004][T01-S013] |
| 竞争防御 | 通过 Groq 授权交易、投资 Intel/Anthropic/Mistral/xAI 等强化主导地位 | [T01-S017][T01-S029] |
| 潜在风险信号 | Groq 交易遭反垄断质询；广泛客户投资被质疑循环融资；部分大型项目存在不确定性 | [T01-S025][T01-S017][T01-S034] |

---

## 5. 主要企业 AI 产品与解决方案

NVIDIA 已形成覆盖“芯片—互连—系统—软件—云服务—运维管理”的全栈企业 AI 产品体系，并以 “AI Factory” 作为核心叙事 [T02-S012][T02-S036][T02-S070]。

### 5.1 数据中心 GPU 与超级芯片

| 产品 | 定位与目标场景 | 关键证据 |
|---|---|---|
| H100 / H200 | 当前主力训练/推理加速卡，面向大规模 AI 训练、推理与 HPC | [T02-S007][T02-S006][T02-S008] |
| B200 / B300 | 新一代旗舰训练/推理 GPU，面向超大规模 AI 工厂与万亿参数模型 | [T02-S008][T02-S051][T02-S054] |
| GB200 / GB300 Grace Blackwell | CPU+GPU 紧耦合超级芯片，面向机架级 AI 工厂、推理与数据处理 | [T02-S021] |
| RTX PRO 6000 / 4500 Blackwell Server Edition | 面向企业数据中心通用加速，主打 AI 推理、Agentic AI、物理 AI、数字孪生、渲染与科学计算 | [T02-S035][T02-S037][T02-S039] |

**客户类型**：超大规模云厂商、大型企业数据中心、科研机构、受监管行业。  
**部署形态**：PCIe 加速卡、SXM 基板、机架级系统。  
**商业化模式**：硬件销售为主；部分 GPU 附赠 NVIDIA AI Enterprise 订阅，例如 H100 PCIe/NVL、H200 NVL 附赠 5 年订阅 [T02-S069][T02-S073]。

---

### 5.2 机架级与系统级产品

| 产品 | 定位 | 证据 |
|---|---|---|
| GB200 NVL72 | 单机架即“百亿亿次级计算机”，集成 72 颗 Blackwell GPU + 36 颗 Grace CPU，NVLink 提供 130 TB/s 低延迟互连；LLM 推理较 H100 提升 30 倍、训练提升 4 倍；全液冷 | [T02-S021][T02-S023][T02-S025] |
| DGX B200 | 8-GPU 企业级 AI 系统 | [T02-S010][T02-S008] |
| DGX SuperPOD | 交钥匙 AI 数据中心基础设施方案，提供规划、设计、部署到持续优化的全生命周期服务，并附 24x7 企业级支持 | [T02-S002][T02-S004][T02-S010] |
| HGX / MGX | OEM GPU 基板平台与模块化服务器参考架构，供 OEM 构建训练、推理、企业 AI、HPC 与边缘服务器 | [T02-S050] |
| NVIDIA-Certified Systems | 覆盖 OEM 服务器与存储的认证体系 | [T02-S052][T02-S056] |
| RTX PRO Servers | 2025年8月发布的新企业数据中心品类，支持风冷/液冷，帮助企业在不完全重建数据中心前提下转向 AI 工厂 | [T02-S012][T02-S035][T02-S036] |
| DGX Spark | 桌面级个人 AI 超级计算机，搭载 GB10 Grace Blackwell 超级芯片，最高 1 PFLOP AI 性能、128GB 内存，可微调最高 700 亿参数模型 | [T02-S060][T02-S061][T02-S062] |

---

### 5.3 网络互连产品

| 产品 | 定位 | 证据 |
|---|---|---|
| NVLink / NVLink Switch | 机架内 GPU scale-up 互连，第五代带宽为 PCIe Gen5 的 14 倍 | [T02-S018][T02-S021] |
| InfiniBand Quantum-2 / Quantum-X800 | 低延迟确定性网络，主导超算与 DGX SuperPOD/TOP500 系统 | [T02-S017][T02-S018][T02-S024] |
| Spectrum-X Ethernet | 专为 AI 优化的以太网平台，宣称生成式 AI 网络性能提升 1.6 倍，在 10 万+ GPU 规模实现 95% 效率；年化收入已超 100 亿美元 | [T02-S016][T02-S018][T02-S020] |
| Spectrum-XGS | 用于跨数据中心互联，构建 giga-scale AI 超级工厂 | [T02-S019] |
| BlueField DPU / ConnectX SuperNIC | 提供数据处理、网络卸载与安全隔离能力 | [T02-S024] |

---

### 5.4 软件栈与 AI 应用平台

| 产品 | 定位 | 证据 |
|---|---|---|
| NVIDIA AI Enterprise / NVIDIA Enterprise 套件 | 云原生软件平台，覆盖 AI 开发、部署与管理；2025年10月起与 Omniverse Enterprise 合并为统一 NVIDIA Enterprise 许可，价格不变，并包含 Run:ai 自托管服务 | [T02-S015][T02-S013][T02-S029] |
| NIM 微服务 | 预打包企业级容器化推理微服务，含基础模型、优化推理引擎、标准 API 与运行时依赖，支持自托管部署 | [T02-S028][T02-S026] |
| NIM Agent Blueprints / NVIDIA AI Blueprints | 面向客服数字人、RAG、药物发现虚拟筛选等典型企业用例的预训练、可定制 AI 工作流目录 | [T02-S027] |
| NeMo 平台 | 端到端定制生成式 AI 开发平台，含 Curator、Customizer、Evaluator、Guardrails 等微服务 | [T02-S075][T02-S076][T02-S078] |
| Omniverse + Cosmos | 数字孪生操作系统与物理 AI 世界模型，面向机器人、自动驾驶、视觉 AI 与工业元宇宙 | [T02-S046][T02-S045][T02-S048] |
| Mission Control + Run:ai | AI 工厂统一运维与编排软件，提供集群供给、遥测可观测、工作负载管理与自主恢复引擎；Run:ai 可提升 GPU 利用率最高 5 倍 | [T02-S064][T02-S065][T02-S067] |
| NVIDIA AI Data Platform / STX | 将 NVIDIA 加速计算、网络与 AI 软件集成到企业存储中，为 RAG 与 AI Agent 提供近实时业务数据查询能力 | [T02-S055][T02-S056][T02-S002] |

---

### 5.5 云服务：DGX Cloud

| 项目 | 内容 | 证据 |
|---|---|---|
| DGX Cloud | NVIDIA 与 AWS、Microsoft Azure、Google Cloud、Oracle Cloud 等合作提供的全托管 AI 训练平台 | [T02-S044][T04-S042] |
| 定价模式 | 官方采用 Request Private Offer 模式；历史公开口径曾给出每实例每月 36,999 美元起；第三方评测亦引用类似价格 | [T02-S044][T04-S041][T02-S041] |
| 云市场按量计费 | NVIDIA AI Enterprise 在 AWS、Google Cloud、Azure、OCI 市场按每 GPU 每小时 1 美元按需提供，另加 CSP 实例费用；支持 1–3 年承诺期私有报价与 BYOL | [T02-S070][T02-S069] |

---

### 5.6 下一代平台：Vera Rubin

| 项目 | 内容 | 证据 |
|---|---|---|
| 平台组成 | 整合 Vera CPU、Rubin GPU、NVLink 6 Switch、ConnectX-9 SuperNIC、BlueField-4 DPU 与 Spectrum-6 交换机 | [T02-S034] |
| 关键规格 | Rubin GPU 约 3,360 亿晶体管、288GB HBM4、单芯片 50 PFLOPS 推理 | [T02-S031] |
| 交付预期 | 官方口径已进入全面生产阶段，首批系统预计 2026 年下半年通过 AWS、Microsoft、Google 等提供；OpenAI、Anthropic、Meta、xAI 已承诺采用 | [T02-S033][T02-S034] |
| 第三方风险信号 | TrendForce 下调 2026 年 Rubin 出货占比预期，从 29% 降至 22%，原因包括 HBM4 验证、互连切换、高功耗与液冷优化 | [T04-S037] |

---

### 5.7 商业化模式总结

| 模式 | 内容 | 证据 |
|---|---|---|
| 硬件销售 | GPU、DGX 系统、网络产品通过 NVIDIA 及 OEM/分销渠道销售 | [T02-S050][T02-S004] |
| 软件订阅 | NVIDIA AI Enterprise 标准价 4,500 美元/GPU/年，多年期与永久许可可选；教育与初创有折扣价 | [T02-S070] |
| 随硬件捆绑 | H100 PCIe/NVL、H200 NVL 附赠 5 年 NVIDIA AI Enterprise 订阅；A800 40GB Active 附赠 3 年 | [T02-S069][T02-S073] |
| 云市场按量 | 1 美元/小时/GPU 按需 + CSP 实例成本；支持承诺期私有报价 | [T02-S070][T02-S069] |
| 托管训练服务 | DGX Cloud 订阅，历史公开口径约 36,999 美元/节点/月 | [T04-S041][T02-S041] |
| 生态交付 | DGX SuperPOD、RTX PRO Servers、AI Data Platform 通过 HPE、Lenovo、Dell、NetApp、DDN 等合作伙伴与 NVIDIA-Certified 体系交付 | [T02-S011][T02-S005][T02-S056] |

---

## 6. 主要竞争对手与竞争格局

### 6.1 NVIDIA 的市场地位

NVIDIA 在企业 AI 基础设施市场仍保持绝对领先地位，但不同来源口径存在差异：

| 口径 | 份额 | 证据 |
|---|---:|---|
| 2024 年 AI 数据中心市场 | 超过 20%，居首 | [T01-S009] |
| 2024 年全球 AI 训练收入 | 约 80% | [T03-S007] |
| AI 加速器市场收入份额 | 约 80% | [T03-S037] |
| AI GPU 市场份额 | 约 86% | [T03-S036] |
| 数据中心 GPU 市场 | 约 90% 口径亦有出现 | [T03-S035] |

**核心护城河**包括 CUDA 软件生态、全栈整合能力、快速产品迭代和庞大合作伙伴网络 [T03-S021][T03-S022][T03-S036]。

---

### 6.2 直接芯片竞争者

#### 6.2.1 AMD：最接近的 GPU 替代方案

- **产品路线**：MI300X → MI350/MI355X → MI400/MI450/Helios 机架级平台。  
- **客户突破**：OpenAI、Meta、Microsoft、Oracle 等。  
- **规模差距**：AMD Instinct 2025 年收入估计约 70–80 亿美元、份额约 5–7%；NVIDIA FY2026 Q4 数据中心收入 623.1 亿美元，而 AMD 同期数据中心收入 53.8 亿美元，约为 AMD 的 11.6 倍。  
- **软件短板**：ROCm 在 PyTorch 路径上进步明显，但自定义 CUDA 内核、Flash Attention、定制 Triton 内核等仍有问题；多数企业生产环境仍以 CUDA 为默认标准。  
- **证据**：[T03-S013][T03-S014][T03-S016][T03-S017][T03-S020][T03-S037][T03-S068][T03-S011][T03-S012]

#### 6.2.2 Intel：边缘化但转为部分合作

- Gaudi 3 定位高性价比企业 AI 推理，但市场存在感弱；Falcon Shores 已取消，转向机架级方案。  
- 渠道伙伴反映推广 Gaudi 需要与 NVIDIA 生态争夺工程师时间。  
- 2025 年 NVIDIA 反向投资 Intel 50 亿美元，两者关系从纯竞争转向部分合作。  
- **证据**：[T03-S064][T03-S067][T03-S002]

#### 6.2.3 华为：中国市场主要替代者

- 昇腾 910C 及 CloudMatrix 384 集群在中国市场构成实质替代，百度、字节跳动、中国移动等已采用。  
- 配合 MindSpore 框架和 CANN 软件构建本土生态锁定。  
- 整体性能仍落后 NVIDIA 约一代，部分来源评估约 3 年差距；良率低于全球领先水平。  
- NVIDIA 在中国市占率从出口管制前约 95% 降至约 50–54%。  
- 2025 年 4 月 H20 被禁售，NVIDIA 计提约 55 亿美元费用；7 月恢复出口，但中国监管与企业采购态度仍造成实际销售受阻。  
- **证据**：[T03-S041][T03-S044][T03-S042][T03-S043][T03-S083][T03-S084][T03-S087]

---

### 6.3 超大规模云厂商自研 ASIC：最大结构性威胁

| 厂商 | 芯片 | 现状 | 证据 |
|---|---|---|---|
| Google | TPU v7 Ironwood | Anthropic 承诺使用至多 100 万颗 TPU；Meta、Salesforce、Midjourney、Replit 为外部客户；TPU 利用率超 91% | [T03-S009][T03-S055][T03-S057] |
| AWS | Trainium2 / Trainium3 | Trainium2 已部署 50 万+ 颗；Trainium3 2026 年 Q2 爬坡；Anthropic 为主要客户 | [T03-S008][T03-S032] |
| Microsoft | Maia 200 | TSMC 3nm，216GB HBM3e，爬坡中，主要服务内部负载 | [T03-S031][T03-S033] |
| Meta | MTIA v2 / MTIA 400 | 内部推理负载，与 Broadcom 合作 | [T03-S008][T03-S032] |

**竞争含义**：

- 自研 ASIC 对推理负载有高达 65% 的 TCO 优势；Google TPU 让 Anthropic 等外部客户相比 NVIDIA 降低成本约 30%，超大规模场景下 TCO 降低 30–50% [T03-S026][T03-S058]。
- TPU 的存在本身成为议价工具：OpenAI 仅凭“可用 TPU”这一替代选项就从 NVIDIA 获得约 30% 折扣 [T03-S058]。
- NVIDIA 约 40% 收入来自四家同时自研竞争芯片的超大规模客户，构成“客户即竞争者”的结构性压力 [T03-S037]。
- 有分析预测 NVIDIA 推理市场份额可能从 90%+ 降至 2028 年的 20–30%，但该预测较激进且方法论未完全披露，应谨慎引用 [T03-S031][T03-S033]。

---

### 6.4 定制 ASIC 设计服务商：Broadcom 与 Marvell

- **Broadcom**：控制约 60–80% 的定制 AI ASIC 市场，为 Google、Meta、Microsoft、OpenAI 等设计芯片；AI 芯片订单储备 730 亿美元，目标 2027 年 AI 芯片年收入 1,000 亿美元。  
- **Marvell**：定制 ASIC 市场第二，约 20–25%，为 Amazon、Microsoft 提供设计合作，预计 2026 年 AI ASIC 收入可达 110 亿美元。  
- Broadcom 和 Marvell 合计控制约 95% 的定制 AI ASIC 共同设计市场。  
- 2026 年定制 ASIC 出货量预计同比增长 44.6%，约为商用 GPU 增速 16.1% 的近三倍。  
- **证据**：[T03-S026][T03-S028][T03-S032][T03-S037][T03-S038]

---

### 6.5 推理专用芯片初创公司

- **Groq**：曾是 NVIDIA 在推理领域最受关注的挑战者，2025 年 12 月被 NVIDIA 以约 200 亿美元技术授权与人才招募方式收编，直接消除主要威胁。  
- **Cerebras**：与 OpenAI 签署数十亿美元推理芯片合同。  
- **SambaNova** 等也在推理市场活跃。  
- NVIDIA 在训练端占绝对主导，但推理端竞争更激烈，这也是 Groq 交易的重要动机。  
- **证据**：[T03-S050][T03-S051][T03-S052][T03-S053]

---

### 6.6 系统厂商与软件平台竞争

#### 6.6.1 OEM/ODM

Dell、HPE、Supermicro、Lenovo 等主要是 NVIDIA 生态伙伴，而非纯竞争者；竞争更多体现在交付能力、机架级集成、液冷和服务能力上。Dell 凭借端到端产品线和 NVIDIA 供货分配处于较强位置 [T03-S045][T03-S046][T03-S049]。

值得注意：2026 年 3 月，Supermicro 三名关联人员因非法向中国出口 5.1 亿美元 NVIDIA 服务器被美国司法部起诉，股价一周下跌 33%，显示系统层供应链合规风险可能改变 OEM 竞争格局 [T03-S049]。

#### 6.6.2 软件平台层

NVIDIA AI Enterprise/NIM 与云厂商 AI 平台既合作又竞争：

- NVIDIA 软件在 AWS、Azure、GCP、OCI 市场上架。
- 云厂商同时用自研芯片和自有平台分流企业 AI 需求。
- 企业多模型、多云策略普及，73% 组织采用混合云，推动跨芯片可移植的软件抽象层发展，长期会削弱 CUDA 锁定。  
- **证据**：[T03-S073][T03-S074][T03-S024]

---

### 6.7 网络与互连层的开放标准竞争

| 标准/联盟 | 目标 | 对 NVIDIA 的影响 | 证据 |
|---|---|---|---|
| UALink 联盟 | 开放 scale-up 互连标准，对标 NVIDIA 专有 NVLink；支持单 Pod 连接最多 1,024 个加速器 | 若 AMD MI400/Helios 等落地，将提供 NVLink 替代路径 | [T03-S063][T03-S079][T03-S080][T03-S081] |
| Ultra Ethernet Consortium | 100+ 成员，目标用开放以太网对标 InfiniBand/Spectrum-X | 长期可能削弱 NVIDIA 网络层专有优势 | [T03-S063][T03-S078][T03-S079][T03-S082] |
| NVIDIA 应对 | Blackwell 世代 Spectrum-X 以太网出货量已大幅超过 Quantum InfiniBand | NVIDIA 自身也在向以太网迁移以守住网络市场 | [T03-S082] |

---

### 6.8 竞争维度比较

| 竞争维度 | NVIDIA 优势 | 竞争者进展 | 证据 |
|---|---|---|---|
| 算力性能 | 实际模型浮点利用率约 50–55%，系统级工程领先 | AMD MI350X FP8 算力追平 B200、显存更大，但 MFU 约 45%；华为以系统规模弥补单芯片差距 | [T03-S037][T03-S040] |
| 生态成熟度 | CUDA 生态深厚，主流框架原生优化 | ROCm 进步但定制内核仍弱；TPU 依托 JAX/XLA | [T03-S021][T03-S022][T03-S011][T03-S031] |
| 软件兼容性 | CUDA 是事实标准 | AI 编程代理和跨芯片抽象层正在降低迁移成本 | [T03-S024][T03-S025] |
| 交付能力 | 需求强劲，Blackwell 订单积压，产品迭代快 | 行业共同受制于 TSMC 先进制程、HBM 和 CoWoS 产能 | [T03-S006][T03-S036] |
| 价格 | 定价权强，毛利率约 72–75% | 定制 ASIC 推理 TCO 优势高达 65%；TPU 外部客户成本低约 30%；AMD 以激进定价和大显存切入 | [T03-S002][T03-S068][T03-S026][T03-S058][T03-S011] |
| 客户锁定 | CUDA + NVLink + 全栈整合，转换成本高 | Anthropic 同时运行 TPU、Trainium、NVIDIA GPU；Meta 同时用 NVIDIA 与 AMD，证明多供应商策略可行 | [T03-S022][T03-S024][T03-S006][T03-S056] |
| 替代方案成熟度 | 训练端替代方案仍不成熟 | 推理端替代方案快速成熟，ASIC 预计将占数据中心推理部署的 37% | [T03-S036][T03-S006] |

---

## 7. 基于内部供应商标准的风险评估

以下评估依据企业内部《AI Supplier Assessment Standard》[KB-D72727B32-C001]。

---

### 7.1 Security：安全风险评估

#### 7.1.1 内部标准要求

AI 技术供应商应提供关于数据存储、数据隔离、访问控制、安全事件响应和模型使用政策的明确信息 [KB-D72727B32-C001]。

#### 7.1.2 公开事实证据

**正面证据：安全认证与漏洞响应体系较完整**

- NVIDIA AI Trust Center 披露其安全合规认证包括：SOC 2、ISO 27001、ISO 27017、ISO 27018、ISO 27701、TISAX 等 [T04-S006]。
- NVIDIA AI Trust Center 明确其安全原则包括：以零信任安全保护 AI 基础设施、数据与模型；为 AI Agent 提供隔离执行、护栏和数据保护控制 [T04-S027]。
- NVIDIA 设有 PSIRT 产品安全事件响应团队，负责接收、调查、内部协调、修复和披露产品安全漏洞 [T04-S046]。
- NVIDIA AI Enterprise 安全白皮书披露其遵循协同漏洞披露流程，符合 ISO/IEC 29147 和 ISO/IEC 30111 标准，并在发现安全问题时发布公开安全公告 [T04-S047]。

**负面证据：合作伙伴环节发生数据泄露**

- 2026年3月9日至5月初，NVIDIA GeForce NOW 云游戏服务在亚美尼亚区域授权合作伙伴 GFN.am 发生数据泄露。泄露内容包括用户邮箱、电话、出生日期、姓名和用户名；密码与支付数据未泄露。入侵发生于 2026年3月9日前后，直到 2026年5月2日才被发现，潜伏期约 54 天，2026年5月5–8日才公开披露 [T04-S016][T04-S017][T04-S018]。
- 2026 年，NVIDIA 重要制造合作伙伴富士康北美工厂遭网络攻击，有报道提及 Apple 和 NVIDIA 数据被窃的说法；富士康称制造运营正在恢复。该事件凸显 NVIDIA 制造与交付链条上的第三方安全风险 [T04-S020]。

#### 7.1.3 风险判断

**中—低风险。**

理由：

1. NVIDIA 在安全认证覆盖度和漏洞响应流程方面满足内部标准对安全事件响应信息透明度的基本要求 [T04-S006][T04-S046][T04-S047]。
2. GeForce NOW 合作伙伴泄露事件说明其区域合作伙伴和授权运营商环节是安全薄弱点，且入侵检测存在延迟 [T04-S016][T04-S018]。
3. 制造合作伙伴遭攻击显示供应链第三方安全边界需要额外合同与技术管控 [T04-S020]。

#### 7.1.4 需关注事项

1. 要求 NVIDIA 提供 SOC 2 Type II、ISO 27001 等认证的具体覆盖范围，确认是否涵盖拟采购的 DGX Cloud、AI Enterprise、NIM 等服务，而非仅限公司层面 [T04-S006]。
2. 就数据存储、数据隔离和访问控制，要求 NVIDIA 提供面向具体产品/服务的书面说明；公开渠道目前主要是原则性表述 [T04-S027]。
3. 若通过 NVIDIA 云合作伙伴或区域运营商使用服务，应将第三方/合作伙伴安全要求写入合同 [T04-S018]。
4. 内部标准要求关注模型使用政策；公开证据主要为 model cards 与可信 AI 原则，需在尽调中索取具体合同条款 [T04-S029][KB-D72727B32-C001]。

---

### 7.2 Compliance：合规风险评估

#### 7.2.1 内部标准要求

供应商应识别适用的隐私、安全和监管义务 [KB-D72727B32-C001]。

#### 7.2.2 公开事实证据

**隐私与安全合规**

- NVIDIA 通过 ISO 27701、ISO 27018 等认证，表明其建立了隐私数据管理框架 [T04-S006]。

**出口管制合规环境高度动荡**

- 2025年4月，美国商务部宣布原允许对华销售的 H20 芯片不再符合出口管制要求，NVIDIA 因此计提 55 亿美元减记 [T04-S001]。
- 2025年7–8月，政策反转，美国商务部向 NVIDIA 发放 H20 出口许可，但附带条件：NVIDIA 需将相关对华销售收入的 15% 上缴美国政府；2025年12月该模式扩展至 H200 芯片，比例升至 25%，并设一年豁免期 [T04-S002][T04-S003]。
- 中国监管机构以安全为由要求中国 AI 企业不要采购 H20，NVIDIA 已停止生产该芯片，形成“双向管制”局面 [T04-S001]。
- 2026 年，台湾地区检方就非法向中国出口 AI 服务器一案起诉 9 人，涉及 NVIDIA 与 Super Micro 员工；案件披露 NVIDIA 高端 AI 服务器出口需严格审查流程，超过 8 台需现场检查 [T04-S004]。
- H200 虽获美国有条件批准对华出口，但截至 2026年1月底中国政府尚未批准进口；NVIDIA 过去一年在中国的芯片销售几乎归零 [T05-S023][T05-S019]。

#### 7.2.3 风险判断

**中—高风险，且波动性极高。**

理由：

1. 隐私/安全合规方面，NVIDIA 有完整认证体系支撑 [T04-S006]。
2. 出口管制是当前 NVIDIA 最大的监管不确定性来源，政策在 2025–2026 年间多次反复，直接造成 55 亿美元减记，并可能影响其对特定区域客户的供货能力与合法性 [T04-S001][T04-S002][T04-S003]。
3. 若我方采购的 NVIDIA 产品/服务涉及跨境部署或特定司法辖区，存在供应合法性突变风险 [T04-S001][T05-S023]。

#### 7.2.4 需关注事项

1. 在合同中加入出口管制变更条款：若因美国、中国或其他司法辖区管制变化导致产品、软件或服务不可用，明确替代方案、退款与责任安排。
2. 核实使用场景、最终用户和部署地点是否落入美国 BIS 管制清单或中国相关限制范围；H20/H200 案例显示管制对象可能精确到具体芯片型号 [T04-S001][T04-S003]。
3. 关注“收入分成换许可”这一新型管制工具的法律稳定性；已有法律分析质疑其合法性，政策再次反转的可能性不可排除 [T04-S002]。

---

### 7.3 Business Continuity：业务连续性风险评估

#### 7.3.1 内部标准要求

关键供应商应提供关于服务可用性、灾难恢复和重大服务依赖风险的信息 [KB-D72727B32-C001]。

#### 7.3.2 公开事实证据

**服务交付模式：DGX Cloud 依托第三方云**

- NVIDIA DGX Cloud 由 Oracle Cloud、Microsoft Azure、Google Cloud 等云服务商托管基础设施，是联合托管模式 [T04-S041][T04-S042]。
- 使用 DGX Cloud 时，服务可用性同时取决于 NVIDIA 和底层云厂商。近一年公开报道中，Azure 曾发生超过 10 小时的大范围宕机 [T04-S021]；AWS 亦多次发生区域性故障，包括 US-East-1 热事件、DNS 错误、中东区域因地缘冲突出现在中断等 [T04-S023][T04-S024][T04-S025]。
- 第三方评测还指出 DGX Cloud Lepton 在实际使用体验上存在问题，例如测试期间无法成功创建 dev pod / 批处理任务，且接入门槛高 [T04-S022]。

**硬件供应链高度集中**

- 制造端：NVIDIA 先进 GPU 几乎全部依赖台积电代工；先进封装 CoWoS 是公认瓶颈。第三方估算 NVIDIA 占用约 60% 的 CoWoS 产能，约 59.5 万片晶圆，并预订了 2026–2027 年扩产的一半以上；前三大客户 NVIDIA、Broadcom、AMD 合计占 85% 以上 [T04-S015]。
- HBM 内存端：SK Hynix 占 NVIDIA Vera Rubin HBM4 分配的约 70%，另一来源称约 2/3；有估计称 NVIDIA 约 90% 的 HBM 来自 SK Hynix；HBM3E 2026 年已售罄，HBM4 正在爬坡 [T04-S013][T04-S015][T04-S014]。
- 分析指出该依赖链为三层结构：韩国 HBM、台湾先进封装、日本独家材料；任何一层中断都会直接冲击 NVIDIA 交付 [T04-S014]。
- 2025 年的供应危机已验证：瓶颈从晶圆制造转移到先进封装与 HBM，直接影响了 NVIDIA 高毛利 GPU 的供应 [T04-S011]。

**新一代产品延迟：连续性风险的现实化案例**

- TrendForce 将 2026 年 Rubin 出货占比预期从 29% 下调至 22%，原因包括 HBM4 验证、CX8→CX9 互连切换、更高功耗、单 GPU 1,800–2,300W 且必须 100% 液冷等挑战；企业将继续依赖 Blackwell，2026 年占出货 70% 以上 [T04-S037][T04-S036]。
- SK Hynix 被报道将 HBM4 量产爬坡推迟至 2026 年三季度；内存短缺已使主要供应商交期延长到 2028 年以后 [T04-S040]。
- 对客户的直接影响：未提前锁定 Rubin 容量的机构在量产后可能面临 20–30 周交付周期；有评论以 Yotta 120 亿美元采购 8 万颗 Rubin 的案例警示，若 NVIDIA 供应链延迟且客户无备选硬件，将没有回退方案 [T04-S036][T04-S038]。

**客户集中度反向影响服务连续性**

- NVIDIA FY2026 财报披露：两大客户占其全年收入约 36%；CFO 确认约一半收入来自前五大云客户；过去一年超大规模云厂商约占其数据中心收入的 55% [T04-S032][T04-S033]。
- 这意味着 NVIDIA 的产能分配、定价和服务优先级可能向少数超大客户倾斜；在供应紧张时，中小规模企业客户的交付优先级和议价能力相对弱势 [T04-S031][T04-S038]。

#### 7.3.3 风险判断

**中—高风险。这是 NVIDIA 作为关键 AI 供应商最突出的风险维度之一。**

理由：

1. DGX Cloud 的可用性叠加了 NVIDIA 与底层云厂商双重故障面，近一年主流云厂商多次发生重大宕机 [T04-S042][T04-S021][T04-S024]。
2. 对 TSMC 先进封装、SK Hynix HBM 的集中度极高，且已被 2025 年供应危机和 2026 年 Rubin 延迟实际验证为交付瓶颈 [T04-S011][T04-S015][T04-S037]。
3. 台海局势与中美出口管制叠加在同一个供应链上：制造在台湾、管制在美国、市场涉及中国 [T04-S012][T04-S001]。

#### 7.3.4 需关注事项

1. 索取 DGX Cloud / AI Enterprise 的 SLA 数值、RTO/RPO、故障历史，以及底层云厂商故障时的责任划分 [KB-D72727B32-C001]。
2. 要求 NVIDIA 书面说明其服务依赖链条，包括云厂商、代工厂、HBM 供应商，并评估单点失效影响 [T04-S014][T04-S015]。
3. 合同中约定交付里程碑、延迟补偿，并评估多云/多供应商冗余，例如同时评估 AMD、自研芯片或其他云上的 GPU 供给 [T04-S037][T04-S036][T04-S038]。
4. 在供应紧张周期，确认我方订单在 NVIDIA 产能分配中的位置；考虑通过云厂商预留实例或长期协议锁定容量 [T04-S031][T04-S036]。
5. 建立地缘风险预案，测试 NVIDIA 供应中断 3–6 个月情景下的业务可承受性 [T04-S012][T04-S014]。

---

### 7.4 Financial Risk：财务风险评估

#### 7.4.1 内部标准要求

评估应考虑收入稳定性、客户集中度、重大资本需求及影响长期服务连续性的因素 [KB-D72727B32-C001]。

#### 7.4.2 收入稳定性：当前极强，但高度绑定单一景气周期

- FY2026 全年收入 2,159 亿美元，同比 +65%；Q4 单季收入 681 亿美元，同比 +73%；全年 GAAP 毛利率 71.1% [T05-S053][T05-S055][T05-S007]。
- FY2027 Q1 收入 816 亿美元，同比 +85%，数据中心收入同比 +92% [T05-S052][T05-S015]。
- FY2027 Q2 收入 962 亿美元，同比 +106%；数据中心收入 890 亿美元，同比 +117%，占总收入约 92.5% [T05-S016][T05-S018]。
- FY2027 Q3 指引 1,080 亿美元，高于分析师预期，且指引中已不含中国数据中心计算收入 [T05-S018][T05-S007]。

**判断**：NVIDIA 当前收入规模和盈利能力极强，短期财务稳定性无忧。但收入 90% 以上集中于数据中心/AI 算力单一业务线，属于典型的周期性资本开支驱动型收入；一旦 AI 基础设施投资周期逆转，收入稳定性将显著恶化 [T05-S018][T05-S055]。

#### 7.4.3 客户集中度：内部标准明确点名的高风险项

- FY2026 Q2 SEC 文件披露：仅两家客户贡献总营收的 39%，其中客户 A 占 23%、客户 B 占 16%；上年同期为 14% 和 11%，集中度明显上升 [T05-S027]。
- 某季度前三大客户合计贡献总营收 50% 以上，分别占 21%、17%、16% [T05-S025]。
- 按最近一年口径，约 55% 的数据中心收入来自超大规模云厂商；大型云服务商约占其数据中心收入的 50%，而数据中心占其总营收约 88% 至 92–94% [T05-S026][T05-S027][T05-S018]。
- FY2026 全年两大客户约占收入 36% [T04-S032]。
- Amazon 与 Alphabet 二季度自由现金流转为负值，Meta 现金创造能力较一年前下降逾 90%，市场担忧大客户持续加码资本开支的能力 [T05-S026]。
- NVIDIA 自身也多次提示客户集中风险：“我们在某些时期曾从少数客户中获得了大量收入，这一趋势可能会持续” [T05-S027]。

**判断**：客户集中度已远超通常警戒水平，且大客户本身也是自研芯片、试图降低 NVIDIA 依赖的竞争对手，例如 Google TPU、AWS Trainium、Microsoft Maia、Meta MTIA [T03-S037][T05-S040]。这构成中—高级别的财务结构性风险。

#### 7.4.4 重大资本需求与长期服务连续性

- NVIDIA 自身资产负债表稳健：截至 2026-01-25，长期债务仅 74.69 亿美元，较上年 84.63 亿美元下降；流动负债 321.63 亿美元 [T05-S046]。
- FY2026 向股东返还 411 亿美元；FY2027 Q1 单季返还约 200 亿美元，并将季度股息从每股 0.01 美元提高至 0.25 美元 [T05-S053][T05-S052]。
- 市值约 5.2 万亿美元 [T05-S017]。
- 但 NVIDIA 正通过金融手段支撑下游需求：与 6 家金融机构联合推出金融计划，拟最多募集 5,000 亿美元资金，推动“GPU 资产化融资”，帮助客户融资采购 [T05-S026]。若客户现金流恶化，可能形成新的风险敞口。
- 中国业务几乎归零：因美中双方出口限制，NVIDIA 过去一年在中国的芯片销售几乎归零；FY2027 Q1 指引已明确剔除中国数据中心计算收入 [T05-S023][T05-S007]。历史上中国占其全球营收 20% 以上，2024 财年超 171 亿美元 [T05-S021]。

**判断**：NVIDIA 自身资本实力和偿债能力极强，供应商自身破产/断供级财务风险为低。但两个因素影响长期连续性判断：

1. 收入高度依赖少数大客户的资本开支意愿与能力；
2. 地缘政治导致特定区域供货连续性已经中断过一次 [T05-S026][T05-S023]。

#### 7.4.5 财务风险综合评级

| 子项 | 判断 | 证据 |
|---|---|---|
| 收入规模与盈利 | 强 | [T05-S053][T05-S007] |
| 资产负债表 | 强 | [T05-S046][T05-S053] |
| 业务集中度 | 高风险集中 | [T05-S055][T05-S018] |
| 客户集中度 | 高风险集中 | [T05-S027][T05-S025] |
| 大客户支付能力 | 需持续监控 | [T05-S026] |
| 区域连续性 | 中—高 | [T05-S023] |

**综合等级：中。**  
其中，自身偿债与持续经营能力为低风险；收入/客户结构集中度为中—高风险 [KB-D72727B32-C001]。

---

### 7.5 Technology Dependency：技术依赖风险评估

#### 7.5.1 内部标准要求

评估应审查对关键硬件、云平台、第三方软件和外部供应链的依赖 [KB-D72727B32-C001]。

#### 7.5.2 CUDA 生态锁定：对我方而言风险最高的一项

- 公开来源对 CUDA 开发者规模存在不同口径：一处称约 200 万开发者 [T03-S021]，另一处称约 400 万开发者 [T05-S031]。
- 有来源称全球 AI 模型训练中 80% 依赖 CUDA 优化库，迁移成本极高 [T05-S031]。
- CUDA 锁定机制包括：
  1. PyTorch 等主流框架优先为 CUDA 优化；
  2. 企业多年积累的手动优化 CUDA 代码资产，迁移面临性能回归风险、结果验证成本和双代码库维护问题；
  3. 开发者技能与人才市场围绕 CUDA 形成，切换成本以年计、以亿美元衡量 [T05-S032][T03-S022]。
- 替代方案成熟度不足：
  - AMD ROCm 生态加速迭代，但要在 2026 年后达到与 CUDA 匹敌的水平仍需持续投入；MI450 要到 2026 年下半年才量产 [T05-S037]。
  - 云厂商自研 ASIC 主要切特定推理场景，非全栈替代；ASIC 服务器占比预计从 2026 年约 27.8% 升至 2030 年近 40% [T05-S036]。
  - 中国国产 GPU 头部产品 CUDA 兼容率突破 95%，但在超大规模集群调度、多模态大模型训练等场景，部分场景性能较 CUDA 生态低 20%–30%，且生态协同不足 [T05-S033]。
- NVIDIA 在 AI 加速器市场收入份额从高峰约 87% 滑向约 75%，但仍占绝对主导 [T05-S038]。

**判断**：若我方 AI 工作负载构建在 NVIDIA GPU + CUDA + cuDNN/TensorRT/NCCL 技术栈上，则形成深度单向依赖。短期内不存在性能、生态、人才三方面都可匹敌的全栈替代。此项风险等级为 **高**。

#### 7.5.3 外部供应链依赖：交付连续性的传导风险

- Blackwell 旗舰芯片完全依赖台积电 CoWoS 封装、SK 海力士 HBM；产能、交付周期、成本不完全由 NVIDIA 掌控 [T05-S041]。
- 行业层面存在 CoWoS 产能、HBM 产能、ABF 基板“三重瓶颈”；台积电 2025 年 CoWoS 产能约 7.5 万片/年仍难完全满足 NVIDIA 等客户 [T05-S043]。
- HBM4 全球仅三家公司能量产：SK 海力士、三星、美光；NVIDIA 为 Rubin 平台将 HBM4 速度要求拉高至 11GB/s，加剧供应链紧张 [T05-S042]。
- Vera Rubin 生产曾传出卡在高端玻纤布等意外环节；另有报道称 NVIDIA 下调 Vera Rubin 所用 HBM4 规格 [T05-S042][T05-S028]。
- NVIDIA 仍是 2027 年 CoWoS 需求最大客户，但 AMD、Google TPU、云厂商自研芯片共同争夺产能，分配竞争加剧 [T05-S045]。
- NVIDIA 自身财报指引反映成本压力：毛利率预计从 75% 回落至 FY2027 Q4 的 71–72%，原因是内存成本上升 [T05-S018]。

**判断**：NVIDIA 制造与封装高度集中于台积电及少数韩/美存储厂商。该依赖会传导至我方：采购交付周期拉长、分配优先级落后于超大规模客户、价格上涨。此项风险等级为 **中—高**。

#### 7.5.4 云平台依赖与地缘可得性

- 若通过云获取 NVIDIA 算力，还叠加云厂商自身优先级风险；各大云厂商同时是自研芯片的推动者 [T05-S040]。
- 出口管制反复：H20 先被限、后恢复、再受中国方面安全审查；H200 有条件放行但中方尚未批准；中国政府要求国家资助的新建数据中心一律使用国产 AI 芯片 [T05-S019][T05-S023]。
- 若我方业务涉及中国境内部署，NVIDIA 硬件可得性存在实质性中断先例：过去一年在中国的芯片销售几乎归零 [T05-S023]。

**判断**：地缘政治与出口管制构成供货可得性的重大外部依赖。若涉中国境内部署，此项风险应升至 **高**。

#### 7.5.5 技术依赖风险综合评级

| 子项 | 判断 | 证据 |
|---|---|---|
| CUDA 软硬件生态锁定 | 高 | [T05-S031][T05-S032][T05-S038] |
| 替代供应商成熟度 | 替代难度高 | [T05-S037][T05-S036][T05-S033] |
| 外部供应链 | 中—高 | [T05-S041][T05-S043][T05-S042] |
| 地缘政治可得性 | 中，涉华部署升至高 | [T05-S023][T05-S019] |

**综合等级：高。**

---

## 8. 综合风险矩阵与采购建议

### 8.1 综合风险矩阵

| 风险维度 | 等级 | 主要事实 | 建议管控措施 |
|---|---:|---|---|
| Security | 中—低 | 认证与漏洞响应完整，但合作伙伴泄露事件暴露第三方边界 [T04-S006][T04-S016] | 核验认证覆盖范围；合同约束第三方安全；索取数据隔离与访问控制说明 |
| Compliance | 中—高 / 高波动 | 出口管制反复，H20/H200 事件造成财务与区域可得性冲击 [T04-S001][T04-S002][T05-S023] | 加入出口管制变更条款；核实最终用户与部署地；建立替代方案 |
| Business Continuity | 中—高 | DGX Cloud 依赖第三方云；CoWoS/HBM/液冷瓶颈；Rubin 延迟信号 [T04-S041][T04-S014][T04-S037] | 索取 SLA/灾备文档；约定交付里程碑；建立多供应商/多云冗余 |
| Financial Risk | 综合中；自身低，结构中高 | 收入高增长但数据中心占比 90%+，大客户集中 [T05-S053][T05-S018][T05-S027] | 监控大客户资本开支；关注 GPU 融资计划风险；避免过度依赖单一供应商 |
| Technology Dependency | 高 | CUDA、NVLink、AI Enterprise/NIM/NeMo 深度锁定；替代方案短期不完全成熟 [T05-S031][T05-S032][T05-S037] | 建立框架/推理服务抽象层；保留跨平台验证；跟踪 AMD/ASIC/国产替代 |

---

### 8.2 对采购与供应商管理的建议

基于内部标准 [KB-D72727B32-C001]，建议将 NVIDIA 列为 **关键依赖型供应商**，并采取以下措施：

#### 8.2.1 合同与尽调层面

1. **认证核验**：要求提供 SOC 2 Type II、ISO 27001/27017/27018/27701 等证书原件及覆盖范围，确认是否涵盖拟采购产品/服务 [T04-S006]。
2. **SLA 与灾备**：要求提供 DGX Cloud、AI Enterprise、NIM 等服务的可用性承诺、RTO/RPO、故障历史、底层云责任划分 [KB-D72727B32-C001]。
3. **出口管制条款**：若因出口管制导致不可用，明确退款、替代方案、服务迁移、责任限制和终止权 [T04-S001][T04-S002]。
4. **交付保障**：针对 GPU/系统交付，约定里程碑、延迟补偿、产能分配优先级和不可抗力处理 [T04-S036][T04-S037]。
5. **第三方安全**：若使用 NVIDIA Cloud Partner、区域运营商或 OEM 交付，将第三方安全与合规义务写入合同 [T04-S018][T04-S020]。

#### 8.2.2 技术架构层面

1. **降低 CUDA 单向锁定**：在框架层、推理服务层、模型格式层建立抽象，避免所有工作负载直接绑定底层 CUDA 内核 [T05-S032]。
2. **保留备选路径**：跟踪 AMD ROCm、Google TPU、AWS Trainium、云厂商 ASIC 及国产 GPU 的成熟度，对可迁移负载进行定期验证 [T05-S037][T05-S036][T05-S033]。
3. **避免单代际锁定**：不要将全部训练与推理负载锁定于单一 GPU 代际，保留跨代际/跨平台验证 [T04-S037][T04-S038]。
4. **多云/多供应商冗余**：对关键业务负载，评估多云 GPU 供给或异构算力池，以降低单供应商中断风险 [T04-S038]。

#### 8.2.3 供应链与业务连续性层面

1. **识别重大服务依赖**：要求 NVIDIA 说明其云厂商、代工厂、HBM 供应商、封装供应商依赖，并评估单点失效影响 [T04-S014][T04-S015]。
2. **建立 BIA 与压力测试**：测试 NVIDIA 供应中断 3–6 个月情景下的业务可承受性 [T04-S012][T04-S014]。
3. **锁定容量**：在供应紧张周期，通过长期协议、云预留实例或 OEM 提前排产锁定容量 [T04-S031][T04-S036]。

#### 8.2.4 财务监控层面

1. **监控大客户资本开支**：重点跟踪 Microsoft、Amazon、Google、Meta 等超大规模客户的资本开支和自由现金流变化 [T05-S026]。
2. **关注客户集中度披露**：跟踪 NVIDIA 财报中前两大/前三大客户占比、超大规模客户与 ACIE 客户收入拆分 [T05-S027][T05-S025][T05-S026]。
3. **关注 GPU 融资计划**：NVIDIA 与金融机构推动最多 5,000 亿美元 GPU 资产化融资，若客户现金流恶化，可能形成新的生态风险敞口 [T05-S026]。
4. **关注中国市场政策**：若我方涉华部署，应持续监控中国对 H200 进口审批、国产芯片替代政策和数据中心建设要求 [T05-S023][T05-S019]。

---

## 9. 信息不足与不确定性说明

以下信息在当前研究材料中不足或存在不确定性，正式采购决策前建议进一步核实：

1. **NVIDIA 安全认证的精确覆盖范围**  
   公开资料显示其列有 ISO 27001、SOC 2 等认证，但未获取各认证覆盖的具体产品/服务范围及有效期，需向 NVIDIA 索取证书与最新 SOC 2 Type II 报告 [T04-S006]。

2. **DGX Cloud 的具体 SLA 数值与灾备细节**  
   公开渠道未检索到 NVIDIA 官方公布的可用性承诺百分比、RTO/RPO 指标；第三方评测反而提示使用体验问题，需通过商务渠道索取 [T04-S022][T04-S041][T04-S042]。

3. **DGX Cloud 官方最新定价**  
   36,999 美元/节点/月为历史公开口径或第三方引用，NVIDIA 官网采用 Request Private Offer 模式，未公开统一价目，需以商务报价为准 [T04-S041][T02-S044][T02-S041]。

4. **各产品线收入拆分**  
   NVIDIA 财报未按单一产品如 DGX、网络、软件披露收入，仅能引用 Spectrum-X 年化超 100 亿美元等零散表述 [T02-S018]。

5. **Vera Rubin 实际交付进度**  
   官方口径为 2026 下半年发货/全面生产，但第三方 TrendForce 下调出货占比并提示延迟；截至目前实际交付量缺乏独立验证数据 [T02-S033][T02-S034][T04-S037]。

6. **Groq 交易监管结果**  
   参议员质询进行中，尚无结论；是否触发正式并购审查未知 [T01-S025]。

7. **NVIDIA 企业 AI 软件独立收入规模**  
   本轮研究未获得 AI Enterprise/NIM 等软件业务独立收入拆分数据 [T01][T02]。

8. **客户集中度最新数据不完整**  
   现有完整披露包括 FY2026 Q2 前两大客户 39%、FY2026 全年两大客户约 36%、某季度前三大超 50%；FY2027 Q2 客户拆分细节未完整获取 [T05-S027][T04-S032][T05-S025]。

9. **5,000 亿美元 GPU 融资计划结构与风险敞口**  
   目前仅知签署 MOU，具体结构、资金来源、风险分担和对我方潜在影响披露有限 [T05-S026]。

10. **部分供应链集中度数据为第三方估算**  
   如 CoWoS 60%、HBM 70% 等份额多为第三方估算，应视为量级参考而非精确值 [T04-S013][T04-S015]。

11. **市场份额口径不一致**  
   NVIDIA 市场份额在不同来源中分别为 70%、80%、86%、90%，取决于统计范围；本报告保留区间表述 [T03-S026][T03-S007][T03-S036][T03-S035]。

12. **CUDA 开发者规模口径不一致**  
   一处来源称约 200 万开发者 [T03-S021]，另一处称约 400 万开发者 [T05-S031]。

13. **我方自身对 NVIDIA 的实际依赖程度未知**  
   本任务未获取我方当前使用 NVIDIA 产品/服务的具体规模、合同条款与部署区域，风险等级判断基于“假设我方深度使用 NVIDIA 算力”的情形。

14. **内部标准未定义量化评分表**  
   “低/中/高”为分析师定性判断，建议后续与采购/风控部门确认正式评级口径 [KB-D72727B32-C001]。

---

## 10. 最终结论

NVIDIA 在最近一年显著强化了其企业 AI 供应能力和市场主导地位。其战略已从单纯提供 GPU 硬件，扩展为以 **AI Factory** 为核心的全栈企业 AI 平台，包括 Blackwell/Vera Rubin 硬件、NVLink/Spectrum-X 网络、AI Enterprise/NIM/NeMo/Omniverse 软件、DGX Cloud 云服务、Mission Control 运维，以及 SAP、ServiceNow、Cisco、Red Hat、Dell、HPE、Supermicro 等深度生态集成 [T01-S002][T01-S004][T02-S012][T02-S015][T02-S028][T02-S044][T02-S064]。

从企业内部供应商评估标准看，NVIDIA 的 **自身财务稳健性很强**，短期破产或断供级风险低 [T05-S053][T05-S046]。但其作为关键 AI 技术供应商存在以下必须重点管控的风险：

1. **技术依赖风险高**：CUDA 生态、NVLink 专有互连、企业软件栈和供应链瓶颈共同形成深度锁定 [T05-S031][T05-S032][T05-S041]。
2. **业务连续性风险中—高**：DGX Cloud 依赖第三方云，硬件交付受制于 TSMC CoWoS、HBM、液冷和产能分配 [T04-S041][T04-S014][T04-S037]。
3. **合规风险中—高且波动大**：出口管制政策反复已经造成实际财务影响和区域供货中断先例 [T04-S001][T04-S002][T05-S023]。
4. **财务结构性风险中—高**：收入高度集中于数据中心业务和少数超大规模客户，大客户资本开支可持续性存在不确定性 [T05-S018][T05-S027][T05-S026]。

**建议结论**：NVIDIA 可作为企业 AI 关键供应商继续引入或扩大合作，但应按“关键依赖型供应商”进行管理，完成认证核验、SLA/灾备审查、出口管制合同条款、交付保障条款、多供应商/多云冗余预案，并持续监控大客户资本开支、供应链瓶颈和地缘政策变化 [KB-D72727B32-C001]。

---

# 附录 A：内部证据

| Evidence ID | 文档 | 内容要点 |
|---|---|---|
| [KB-D72727B32-C001] | supplier_policy.md | AI Supplier Assessment Standard：Security、Compliance、Business Continuity、Financial Risk、Technology Dependency |
| [KB-D10D9F4B2-C001] | research_standard.md | Enterprise Research Report Standard：完整报告应覆盖公司背景、产品、近期发展、竞争格局、财务信息、风险和证据 |

---

# 附录 B：关键公开证据与 URL 节选

以下列出报告正文中关键结论对应的主要公开来源。正文中所有 Source ID 均可在原始 External Source Index 中进一步追溯。

## B.1 企业 AI 业务动作与生态

| Source ID | 标题 | URL |
|---|---|---|
| [T01-S010] | OpenAI 与英伟达宣布达成战略合作伙伴关系，计划使用英伟达系统部署 10 吉瓦 AI 数据中心 | https://openai.com/zh-Hans-CN/index/openai-nvidia-systems-partnership |
| [T01-S047] | Microsoft, NVIDIA and Anthropic announce strategic partnerships | https://blogs.microsoft.com/blog/2025/11/18/microsoft-nvidia-and-anthropic-announce-strategic-partnerships |
| [T01-S050] | Microsoft, Nvidia to Invest Up to $15 Billion in Anthropic | https://www.bloomberg.com/news/articles/2025-11-18/microsoft-nvidia-to-invest-up-to-15-billion-in-anthropic |
| [T01-S051] | Anthropic valued in range of $350 billion following investment deal | https://www.cnbc.com/2025/11/18/anthropic-ai-azure-microsoft-nvidia.html |
| [T01-S035] | Nvidia bets on Intel: What it means for IT leaders | https://www.techtarget.com/it-strategy/feature/Nvidia-bets-on-Intel-What-it-means-for-IT-leaders |
| [T01-S036] | Nvidia’s $5 Billion Intel Bet Was Worth $30 Billion by June | https://finance.yahoo.com/markets/stocks/articles/nvidia-5-billion-intel-bet-213940172.html |
| [T01-S037] | Nvidia finalizes its roughly 4%, $5 billion stake in Intel | https://qz.com/nvidia-intel-5-billion-deal-done-ai-partnership |
| [T01-S025] | Nvidia’s $20 billion Groq deal queried by Warren, Blumenthal | https://www.mercurynews.com/2026/03/20/nvidias-20-billion-groq-deal-queried-by-warren-blumenthal |
| [T01-S027] | Nvidia to license technology from inference chip startup Groq in reported $20B deal | https://siliconangle.com/2025/12/24/nvidia-license-technology-inference-chip-startup-groq-reported-20b-deal |
| [T01-S028] | Scoop: Nvidia deal a big win for Groq employees and investors | https://www.axios.com/2025/12/28/nvidia-groq-shareholders |
| [T01-S029] | Nvidia buys AI chip startup Groq's assets for $20 billion in the company's biggest deal ever | https://www.tomshardware.com/tech-industry/artificial-intelligence/nvidia-buys-ai-chip-startup-groqs-assets-for-usd20-billion-in-the-companys-biggest-deal-ever-transaction-includes-acquihires-of-key-groq-employees-including-ceo |
| [T01-S017] | Nvidia's Groq deal underscores how the AI chip giant uses its massive balance sheet to maintain dominance | https://finance.yahoo.com/news/nvidias-groq-deal-underscores-how-the-ai-chip-giant-uses-its-massive-balance-sheet-to-maintain-dominance-183347248.html |
| [T01-S016] | SpaceX sheds $620 billion in market value within days of its record IPO | https://startupfortune.com/spacex-sheds-620-billion-in-market-value-within-days-of-its-record-ipo-as-investors-punish-the-cursor-deal |
| [T01-S018] | 2025’s Biggest AI Deals, Ranked | https://www.forbes.com/sites/tylerroush/2025/12/29/softbank-will-buy-digitalbridge-for-4-billion-making-2025s-top-ai-deals-full-list-ranked |
| [T01-S045] | Nvidia GTC Paris Keynote Headlines VivaTech June 17-20 | https://www.techtimes.com/articles/318178/20260610/nvidia-gtc-paris-keynote-headlines-vivatech-june-17-20ai-factories-sovereign-ai-robotics-europe.htm |
| [T01-S002] | Enterprise Software Leaders Build AI Agents With NVIDIA | https://nvidianews.nvidia.com/news/enterprise-software-leaders-build-ai-agents-with-nvidia |
| [T01-S003] | NVIDIA Ignites the Next Industrial Revolution in Knowledge | http://nvidianews.nvidia.com/news/ai-agents |
| [T01-S004] | Nvidia launches enterprise AI agent platform with Adobe, Salesforce, SAP among 17 adopters at GTC 2026 | https://venturebeat.com/technology/nvidia-launches-enterprise-ai-agent-platform-with-adobe-salesforce-sap-among |
| [T01-S001] | NVIDIA GTC 2026: Governing the Autonomous Workforce - ServiceNow Newsroom | https://newsroom.servicenow.com/press-releases/details/2026/NVIDIA-GTC-2026-Governing-the-Autonomous-Workforce/default.aspx |
| [T01-S013] | NVIDIA GTC: How SAP and NVIDIA Advance Enterprise AI | https://news.sap.com/2026/03/how-sap-nvidia-advance-ai-enterprise-transformation |
| [T01-S005] | Cisco Delivers AI Innovations across Neocloud, Enterprise and Telecom with NVIDIA | https://newsroom.cisco.com/c/r/newsroom/en/us/a/y2025/m10/cisco-delivers-ai-networking-innovations-across-neocloud-enterprise-and-telecom-with-nvidia.html |
| [T01-S015] | Accelerate enterprise AI with Cisco, Red Hat, and NVIDIA | https://blogs.cisco.com/datacenter/accelerate-enterprise-ai-with-cisco-red-hat-and-nvidia |
| [T01-S014] | NTT DATA unveils NVIDIA-powered enterprise AI factories | https://www.nttdata.com/en-us/news/2026/ntt-data-unveils-nvidia-powered-enterprise-ai-factories |
| [T01-S011] | Supermicro Launches Seven AI Data Platform Solutions with NVIDIA | https://ir.supermicro.com/news/news-details/2026/Supermicro-Launches-Seven-AI-Data-Platform-Solutions-with-NVIDIA-and-Leading-Ecosystem-Partners-to-Accelerate-Enterprise-AI-Innovation/default.aspx |
| [T01-S012] | Dell's Stock Has Soared in 2026. Is It a Good Buy Right Now? | https://marketwise.com/investing/dell-ai-transformation-stock-outlook-is-it-good-buy-right-now |
| [T01-S021] | Nvidia GTC-DC Event Highlights AI, Quantum, And 6G Advances | https://www.forbes.com/sites/karlfreund/2025/10/28/nvidia-gtc-dc-event-highlights-ai-quantum-and-6g-advances/ |
| [T01-S022] | Nvidia's day of deals, the Fed decision, Boeing earnings and more | https://www.cnbc.com/2025/10/29/5-things-to-know-before-the-stock-market-opens.html |
| [T01-S040] | GTC Taipei Perspectives and Taiwan AI Supply Chain Depth Insights from Computex 2026 | https://tspasemiconductor.substack.com/p/from-gtc-taipei-to-computex-2026 |
| [T01-S042] | NVIDIA GTC Taipei at COMPUTEX: Live Updates on What’s Next in AI | https://blogs.nvidia.com/blog/nvidia-gtc-taipei-computex-2026-news |
| [T01-S009] | 人工智能数据中心市场规模、份额及预测报告 | https://www.gminsights.com/zh/industry-analysis/ai-data-center-market |
| [T01-S044] | The US AI Trap: Why the EU AI Act is suddenly Europe's strongest weapon | https://xpert.digital/en/europes-most-powerful-weapon |
| [T01-S046] | AI data center: The real reason for Google's sudden billion-dollar love affair with Germany | https://xpert.digital/en/google-ai-data-center-in-germany |
| [T01-S034] | OpenAI shelves Stargate UK in blow to Britain’s AI ambitions | https://www.theguardian.com/technology/2026/apr/09/openai-pulls-out-of-landmark-31bn-uk-investment |

## B.2 产品与解决方案

| Source ID | 标题 | URL |
|---|---|---|
| [T02-S007] | H100 GPU - NVIDIA | https://www.nvidia.com/en-us/data-center/h100 |
| [T02-S008] | Compare NVIDIA H200 & DGX B200 GPUs for AI Workloads | https://acecomputers.com/nvidia-h200-vs-dgx-b200-ai-accelerator |
| [T02-S010] | DGX B200: The Foundation for Your AI Factory | https://www.nvidia.com/en-us/data-center/dgx-b200 |
| [T02-S002] | DGX SuperPOD: AI Infrastructure for Enterprise Deployments | https://www.nvidia.com/en-us/data-center/dgx-superpod |
| [T02-S004] | NVIDIA DGX SuperPOD: Scalable Infrastructure for AI Leadership | https://images.nvidia.com/aem-dam/Solutions/Data-Center/gated-resources/nvidia-dgx-superpod-a100.pdf |
| [T02-S021] | GB200 NVL72 | https://www.nvidia.com/en-us/data-center/gb200-nvl72 |
| [T02-S023] | NVIDIA GB200 NVL72 - Powering the New Era of Computing | https://polarise.eu/ai-factories/hw/gb200 |
| [T02-S025] | Supermicro NVIDIA GB200 NVL72 SuperCluster | https://www.supermicro.com/manuals/brochure/Brochure-AI-SuperCluster-NVIDIA-GB200-NVL72.pdf |
| [T02-S050] | HGX, DGX, MGX: NVIDIA's Server Platforms | https://www.amcompute.com/blog/hgx-dgx-mgx |
| [T02-S052] | NVIDIA-Certified Systems | https://docs.nvidia.com/certification-programs/latest/nvidia-certified-systems.html |
| [T02-S012] | Industry Leaders Transform Enterprise Data Centers for the AI Era With NVIDIA RTX PRO Servers | https://investor.nvidia.com/news/press-release-details/2025/Industry-Leaders-Transform-Enterprise-Data-Centers-for-the-AI-Era-With-NVIDIA-RTX-PRO-Servers/default.aspx |
| [T02-S035] | RTX PRO Servers for Building Enterprise AI Factories | https://www.nvidia.com/en-us/data-center/products/rtx-pro-server |
| [T02-S036] | NVIDIA RTX PRO Servers Speed Trillion-Dollar Enterprise IT Industry Transition to AI Factories | https://nvidianews.nvidia.com/news/nvidia-rtx-pro-servers-speed-trillion-dollar-enterprise-it-industry-transition-to-ai-factories |
| [T02-S037] | NVIDIA RTX PRO 6000 Server GPU Boosts Enterprise AI Inference | https://www.linkedin.com/posts/world-wide-technology_the-new-nvidia-rtx-pro-6000-blackwell-server-activity-7410333574249480192-MfV9 |
| [T02-S039] | Unveiling the Power of the NVIDIA RTX PRO 6000 Blackwell Server Edition | https://vrlatech.com/unveiling-the-power-of-the-nvidia-rtx-pro-6000-blackwell-server-edition-revolutionizing-ai-and-visual-computing-for-the-data-center |
| [T02-S016] | NVIDIA Spectrum-X Ethernet Platform for AI Networking | https://www.nvidia.com/en-us/networking/spectrumx |
| [T02-S018] | Nvidia networking roadmap: Ethernet, InfiniBand, co-packaged optics | https://www.networkworld.com/article/4050881/nvidia-networking-roadmap-ethernet-infiniband-co-packaged-optics-will-shape-data-center-of-the-future.html |
| [T02-S020] | High-Performance Spectrum Ethernet Platform for AI Networking | https://www.nvidia.com/en-us/networking/products/ethernet |
| [T02-S019] | Breaking the barriers of AI networking | https://www.facebook.com/NVIDIANetworking/posts/-breaking-the-barriers-of-ai-networkingnvidia-spectrum-x-ethernet-is-redefining-/1203579691801682 |
| [T02-S015] | NVIDIA AI Enterprise Documentation | https://docs.nvidia.com/ai-enterprise/index.html |
| [T02-S013] | NVIDIA Software Product Guide | https://lenovopress.lenovo.com/lp2289-nvidia-software-product-guide |
| [T02-S029] | NVIDIA AI Enterprise | https://www.nvidia.com/en-us/data-center/products/ai-enterprise |
| [T02-S028] | NVIDIA NIM Microservices for Accelerated AI Inference | https://www.nvidia.com/en-us/ai-data-science/products/nim-microservices |
| [T02-S026] | NVIDIA NIM and Inference Microservices | https://introl.com/blog/nvidia-nim-inference-microservices-enterprise-deployment-guide-2025 |
| [T02-S027] | NVIDIA and Global Partners Launch NIM Agent Blueprints | https://nvidianews.nvidia.com/news/nvidia-and-global-partners-launch-nim-agent-blueprints-for-enterprises-to-make-their-own-ai |
| [T02-S075] | Custom Models for Generative AI | https://www.nvidia.com/en-us/ai/foundry |
| [T02-S076] | Unlocking the Power of Enterprise-Ready LLMs with NVIDIA NeMo | https://developer.nvidia.com/blog/unlocking-the-power-of-enterprise-ready-llms-with-nemo |
| [T02-S078] | NeMo | https://www.nvidia.com/en-us/ai-data-science/products/nemo |
| [T02-S046] | NVIDIA Expands Omniverse With Generative Physical AI | https://investor.nvidia.com/news/press-release-details/2025/NVIDIA-Expands-Omniverse-With-Generative-Physical-AI/default.aspx |
| [T02-S045] | Siemens & NVIDIA: What is the Industrial Metaverse? | https://manufacturingdigital.com/news/siemens-nvidia-what-is-the-industrial-metaverse |
| [T02-S048] | Into the Omniverse: How Industrial AI and Digital Twins Accelerate Design | https://blogs.nvidia.com/blog/industrial-ai-digital-twins-omniverse |
| [T02-S064] | Automating AI Factories with NVIDIA Mission Control | https://developer.nvidia.com/blog/automating-ai-factory-operations-with-nvidia-mission-control |
| [T02-S067] | Run Models for AI Factories | https://www.nvidia.com/en-us/data-center/mission-control |
| [T02-S065] | NVIDIA Mission Control on GPU Cloud | https://www.spheron.network/blog/nvidia-mission-control-ai-factory-gpu-cloud-guide |
| [T02-S055] | AI Data Platform for Enterprise Infrastructure | https://www.nvidia.com/en-us/data-center/ai-data-platform |
| [T02-S056] | NVIDIA and Storage Industry Leaders Unveil New Class of Enterprise Infrastructure | https://nvidianews.nvidia.com/news/nvidia-and-storage-industry-leaders-unveil-new-class-of-enterprise-infrastructure-for-the-age-of-ai |
| [T02-S044] | NVIDIA’s AI factory in the cloud | https://www.nvidia.com/en-us/data-center/dgx-cloud |
| [T04-S041] | NVIDIA Launches DGX Cloud | https://nvidianews.nvidia.com/news/nvidia-launches-dgx-cloud-giving-every-enterprise-instant-access-to-ai-supercomputer-from-a-browser |
| [T02-S041] | Top 12 Cloud GPU Providers for AI and ML in 2026 | https://www.runpod.io/articles/guides/top-cloud-gpu-providers |
| [T02-S069] | NVIDIA AI Enterprise Licensing | https://docs.nvidia.com/ai-enterprise/planning-resource/licensing-guide/latest/licensing.html |
| [T02-S070] | NVIDIA AI Enterprise Pricing | https://docs.nvidia.com/ai-enterprise/planning-resource/licensing-guide/latest/pricing.html |
| [T02-S073] | Activate NVIDIA AI Enterprise | https://www.nvidia.com/en-us/data-center/activate-license |
| [T02-S060] | NVIDIA DGX Spark - AI Supercomputer Wherever You Go | https://www.exxactcorp.com/blog/hpc/nvidia-dgx-spark-ai-supercomputer-wherever-you-go |
| [T02-S061] | NVIDIA DGX Spark: AI Supercomputer on Your Desk | https://www.nvidia.com/en-us/products/workstations/dgx-spark |
| [T02-S031] | NVIDIA Rubin GPU: 336B Transistors, T Orders | https://tech-insider.org/nvidia-gtc-2026-rubin-gpu-analysis |
| [T02-S033] | Nvidia Touts New Storage Platform, Confidential Computing For Vera Rubin NVL72 | https://www.crn.com/news/data-center/2026/nvidia-touts-new-storage-platform-confidential-computing-for-vera-rubin-nvl72-server-rack |
| [T02-S034] | Nvidia Blackwell successor Rubin releases in 2026 | https://www.techzine.eu/news/infrastructure/137668/nvidia-blackwell-successor-rubin-releases-in-2026-significant-performance-boost |
| [T02-S011] | HPE advances government and enterprise AI adoption through secure AI factory innovations with NVIDIA | https://www.hpe.com/us/en/newsroom/press-release/2025/10/hpe-advances-government-and-enterprise-ai-adoption-through-secure-ai-factory-innovations-with-nvidia.html |

## B.3 竞争格局

| Source ID | 标题 | URL |
|---|---|---|
| [T03-S007] | AI Accelerators Market Size, Share & 2031 Trends Report | https://www.mordorintelligence.com/industry-reports/ai-accelerators-market |
| [T03-S036] | Nvidia Competitors 2026: Top Rivals, AI Market Share And Industry Analysis | https://www.companieshistory.com/nvidia-competitors |
| [T03-S037] | AMD vs NVIDIA AI GPU Market Share 2026 | https://siliconanalysts.com/analysis/amd-vs-nvidia-ai-gpu-market-share-2026 |
| [T03-S021] | NVIDIA’s AI Dominance: How Full-Stack Thinking Built an Unassailable Moat | https://www.cloudsyntrix.com/blogs/nvidias-ai-dominance-how-full-stack-thinking-built-an-unassailable-moat |
| [T03-S022] | Why Nvidia's True Moat Isn't Chips, But CUDA | https://www.aminext.blog/en/post/why-nvidia-s-true-moat-isn-t-chips-but-cuda-an-investor-s-guide-to-the-ecosystem-wars |
| [T03-S011] | NVIDIA Blackwell vs AMD MI350: AI GPU Comparison 2026 | https://tech-insider.org/nvidia-blackwell-vs-amd-mi350-2026 |
| [T03-S012] | NVIDIA AMD AI chips in 2026: Blackwell vs MI400 Compared | https://gpuinsights.net/nvidia-amd-ai-chips-data-center-war-2026 |
| [T03-S013] | AMD MI350 GPU Competition | https://introl.com/blog/amd-mi350-gpu-competition-nvidia-enterprise-infrastructure |
| [T03-S014] | AMD Instinct GPUs for Enterprise AI and HPC | https://www.datamonsters.com/technologies/amd-instinct-gpus |
| [T03-S016] | Is It Too Late to Buy Advanced Micro Devices (AMD) Stock After Its 12-Month Gain of 300%? | https://www.theglobeandmail.com/investing/markets/stocks/AMD/pressreleases/2404677/is-it-too-late-to-buy-advanced-micro-devices-amd-stock-after-its-12-month-gain-300 |
| [T03-S017] | AMD’s MI350: The AI Accelerator That Could Challenge Nvidia’s Dominance In 2026 | https://seekingalpha.com/article/4856532-amds-mi350-ai-accelerator-that-could-challenge-nvidias-dominance-in-2026 |
| [T03-S020] | AMD Helios Faces Nvidia Vera Rubin at July 23 Keynote | https://www.techtimes.com/articles/319338/20260629/amd-helios-faces-nvidia-vera-rubin-july-23-keynote-memory-leads-training-trails.htm |
| [T03-S068] | Nvidia vs. AMD: Which Stock Will Outperform The Market In 2026 | https://finance.yahoo.com/markets/stocks/articles/nvidia-vs-amd-stock-outperform-174736135.html |
| [T03-S064] | Intel Cancels Falcon Shores AI Chip To Focus On ‘Rack-Scale Solution’ | https://www.crn.com/news/components-peripherals/2025/intel-cancels-falcon-shores-ai-chip-to-focus-on-system-level-solution |
| [T03-S067] | Intel Unleashes Enterprise AI with Gaudi 3 | https://www.intc.com/news-events/press-releases/detail/1689/intel-unleashes-enterprise-ai-with-gaudi-3-ai-open-systems |
| [T03-S041] | Huawei's New 910C BEAST Just Made NVIDIA's Billion-Dollar | https://www.youtube.com/watch?v=LXHqJJnB0So |
| [T03-S044] | China's AI Chip Race: Tech Giants Challenge Nvidia | https://spectrum.ieee.org/china-ai-chip |
| [T03-S042] | Despite Huawei’s progress, Nvidia continues to dominate AI chips market in China | https://merics.org/en/comment/despite-huaweis-progress-nvidia-continues-dominate-ai-chips-market-china |
| [T03-S043] | Chinese domestic AI chips 3 years behind US-Taiwan | https://ai2027-tracker.com/predictions/china-chip-gap |
| [T03-S083] | 特朗普禁NVIDIA芯片出口中国 “副作用”让华为受惠？ | https://www.dw.com/zh/%E7%89%B9%E6%9C%97%E6%99%AE%E7%A6%81nvidia%E8%8A%AF%E7%89%87%E5%87%BA%E5%8F%A3%E4%B8%AD%E5%9B%BD-%E5%89%AF%E4%BD%9C%E7%94%A8%E8%AE%A9%E5%8D%8E%E4%B8%BA%E5%8F%97%E6%83%A0/a-72307734 |
| [T03-S084] | H20芯片解禁，怎么看？ | https://paper.people.com.cn/rmrbhwb/pc/content/202507/22/content_30089382.html |
| [T03-S087] | 英伟达称美国政府批准该公司向中国出口人工智能芯片 | https://cn.nytimes.com/technology/20250716/nvidia-ai-chip-sales-china |
| [T03-S008] | Hyperscaler AI ASIC Market: Google, AWS, Microsoft & More | https://hashrateindex.com/blog/hyperscaler-ai-asic-market-report-part-1 |
| [T03-S009] | Nvidia Blackwell, Google TPUs, AWS Trainium: Comparing top AI chips | https://www.cnbc.com/2025/11/21/nvidia-gpus-google-tpus-aws-trainium-comparing-the-top-ai-chips.html |
| [T03-S031] | Hyperscaler Custom AI Chips in 2026 | https://www.spheron.network/blog/hyperscaler-custom-ai-chips-2026-trainium-tpu-maia-mtia-vs-nvidia-gpu |
| [T03-S032] | Custom ASIC Market 2026: Hyperscalers vs NVIDIA | https://oplexa.com/blogs/custom-asic-market-2026-hyperscalers-ditching-nvidia |
| [T03-S055] | Google TPU 8t and 8i: 121 Exaflops, $21B Nvidia Challenge | https://tech-insider.org/google-tpu-8t-8i-broadcom-mediatek-nvidia-2026 |
| [T03-S057] | Google TPUv7: The 900lb Gorilla In The Room | https://newsletter.semianalysis.com/p/tpuv7-google-takes-a-swing-at-the |
| [T03-S058] | How Google’s TPUs are reshaping the economics of large-scale AI | https://venturebeat.com/orchestration/how-googles-tpus-are-reshaping-the-economics-of-large-scale-ai |
| [T03-S026] | The custom AI ASIC state of play | https://www.tomshardware.com/tech-industry/semiconductors/custom-ai-asics-examined-from-broadcom-to-mtia |
| [T03-S028] | Broadcom AI ASIC dominance | https://x.com/jukan05/status/1929684382824255612 |
| [T03-S038] | Top 30+ AI Chip Makers: NVIDIA & Its Competitors | https://aimultiple.com/ai-chip-makers |
| [T03-S050] | Nvidia Snaps Up Groq in Record $20B AI Chip Acquisition | https://www.techbuzz.ai/articles/nvidia-snaps-up-groq-in-record-20b-ai-chip-acquisition |
| [T03-S051] | Nvidia expands AI empire with Groq licensing deal | https://nypost.com/2025/12/24/business/nvidia-expands-ai-empire-with-groq-licensing-deal-poaching-startups-top-execs |
| [T03-S052] | Nvidia, joining Big Tech deal spree, to license Groq technology | https://www.reuters.com/business/nvidia-buy-ai-chip-startup-groq-about-20-billion-cnbc-reports-2025-12-24 |
| [T03-S053] | Report: Nvidia is working on a top-secret AI inference chip | https://siliconangle.com/2026/03/01/report-nvidia-working-top-secret-ai-inference-chip-debut-next-month |
| [T03-S045] | Top 10 AI Server Companies Driving U.S. Market Growth | https://www.datamintelligence.com/blogs/top-ai-server-companies-us-market-growth |
| [T03-S046] | On-Prem AI Infrastructure: Comparing Dell, HPE, & More | https://intuitionlabs.ai/articles/on-prem-ai-infrastructure-comparison |
| [T03-S049] | Will Supermicro's Crisis Shift to New Dell & HPE GPU Platforms? | https://futurumgroup.com/insights/will-supermicros-legal-crisis-shift-server-market-share-to-new-dell-and-hpe-gpu-platforms |
| [T03-S073] | Gate.AI vs AWS Bedrock vs Azure OpenAI | https://gate.ai/zh/blog/gate.ai-vs-aws-bedrock-vs-azure-openai-what-sets-these-enterprise-ai-platforms-apart |
| [T03-S074] | NVIDIA AI Enterprise | https://www.nvidia.cn/data-center/products/ai-enterprise?ncid=no-ncid |
| [T03-S063] | GPU Networking for AI Clusters: InfiniBand vs RoCE vs Spectrum-X | https://www.spheron.network/blog/gpu-networking-infiniband-roce-spectrum-x-guide |
| [T03-S078] | Battle between NVDA's Proprietary Spectrum-X Ethernet Platform and Open Standard UEC and UAL | https://discussion.fool.com/t/battle-between-nvdas-proprietary-spectrum-x-ethernet-platform-and-open-standard-uec-and-ual/121642 |
| [T03-S079] | The AI Network War: Can Ethernet Break NVIDIA's Moat? | https://www.youtube.com/watch?v=13k5P0puhtc |
| [T03-S080] | UALink - Wikipedia | https://en.wikipedia.org/wiki/UALink |
| [T03-S081] | UALink vs NVLink: Open GPU Interconnect for AI Inference | https://www.spheron.network/blog/ualink-vs-nvlink-open-gpu-interconnect-2026 |
| [T03-S082] | The New AI Networks | https://newsletter.semianalysis.com/p/the-new-ai-networks-ultra-ethernet-uec-ualink-vs-broadcom-scale-up-ethernet-sue |

## B.4 安全、合规与业务连续性

| Source ID | 标题 | URL |
|---|---|---|
| [T04-S006] | AI Trust Center Security & Compliance | https://www.nvidia.com/en-us/ai-trust-center/security-compliance |
| [T04-S027] | AI Trust Center | https://www.nvidia.com/en-us/ai-trust-center |
| [T04-S046] | Nvidia PSIRT Policies | https://www.nvidia.com/en-us/product-security/psirt-policies |
| [T04-S047] | Vulnerability Response — NVIDIA AI Enterprise Security White Paper | https://docs.nvidia.com/ai-enterprise/planning-resource/ai-enterprise-security-white-paper/latest/vulnerability-response.html |
| [T04-S029] | Six Steps Toward AI Security | https://blogs.nvidia.com/blog/ai-security-steps |
| [T04-S016] | NVIDIA Confirms GeForce Data Breach Exposed Users’ Personal Data | https://gbhackers.com/nvidia-confirms-geforce-data-breach |
| [T04-S017] | NVIDIA Data Breach Reportedly Exposes Personal Information of GeForce Users | https://cybersecuritynews.com/nvidia-data-breach-geforce-users |
| [T04-S018] | NVIDIA GeForce NOW Data Breach: Armenian Users’ Personal Information Exposed | https://www.rescana.com/post/nvidia-geforce-now-data-breach-armenian-users-personal-information-exposed-via-gfn-am-partner-system |
| [T04-S020] | Foxconn confirms cyberattack amid claims of stolen Apple and Nvidia data | https://www.computing.co.uk/news/2026/security/foxconn-confirms-cyberattack-amid-claims-of-stolen-apple-and-nvidia-data |
| [T04-S001] | Ball game’s over—the US is out of the AI chip market in China | https://www.brookings.edu/articles/ball-games-over-the-us-is-out-of-the-ai-chip-market-in-china |
| [T04-S002] | Trump's Illegal AI Chip Export Controls, and Who Can Challenge | https://www.lawfaremedia.org/article/trump-s-illegal-ai-chip-export-controls--and-who-can-challenge-them |
| [T04-S003] | The US pivot on regulating AI diffusion | https://www.iiss.org/publications/strategic-comments/2025/12/the-us-pivot-on-regulating-ai-diffusion |
| [T04-S004] | Taiwan charges 9 over illegal AI server exports to China | https://www.pbs.org/newshour/world/taiwan-charges-9-over-illegal-ai-server-exports-to-china-including-nvidia-and-super-micro-staffers |
| [T04-S042] | NVIDIA’s AI factory in the cloud | https://www.nvidia.com/en-us/data-center/dgx-cloud |
| [T04-S021] | Azure outage disrupts VMs and identity services for over 10 hours | https://www.networkworld.com/article/4127142/azure-outage-disrupts-vms-and-identity-services-for-over-10-hours.html |
| [T04-S023] | AWS DNS error hits DynamoDB | https://www.networkworld.com/article/4075446/aws-dns-error-hits-dynamodb-causing-problems-for-multiple-services-and-customers.html |
| [T04-S024] | AWS hit by US-East-1 outage after data center thermal event | https://www.networkworld.com/article/4168878/aws-hit-by-us-east-1-outage-after-data-center-thermal-event.html |
| [T04-S025] | AWS Middle East Outage After Data Centers Hit by Drone Strikes | https://www.datacenterknowledge.com/outages/aws-middle-east-outage-after-data-center-hit-by-unidentified-objects |
| [T04-S022] | ClusterMAX 2.0: The Industry Standard GPU Cloud Rating System | https://newsletter.semianalysis.com/p/clustermax-20-the-industry-standard |
| [T04-S011] | AI Chip Supply Chain Risk 2026: Your Essential Guide | https://enkiai.com/ai-market-intelligence/ai-chip-supply-chain-risk-2026-your-essential-guide |
| [T04-S012] | NVIDIA Supply Chain Risk Analysis | https://www.scribd.com/document/1002795292/NVIDIA-Supply-Chain-Risk-Analysis |
| [T04-S013] | NVIDIA Spotlight — AI GPU Supply Chain, HBM4, CoWoS | https://semiconductorx.com/spotlight-nvidia.html |
| [T04-S014] | The Memory Chokepoint: Korea's HBM Monopoly | https://forcedalpha.com/news/korea-hbm-supply-chain-dependency |
| [T04-S015] | TSMC CoWoS Capacity 2026: Sold Out, 2nm Booked | https://siliconanalysts.com/analysis/foundry-allocation-status-q1-2026 |
| [T04-S036] | NVIDIA Rubin GPU: 336B Transistors, T Orders | https://tech-insider.org/nvidia-gtc-2026-rubin-gpu-analysis |
| [T04-S037] | Nvidia Rubin GPUs may be delayed, slowing the next phase of AI infrastructure | https://www.networkworld.com/article/4156508/nvidia-rubin-gpus-may-be-delayed-slowing-the-next-phase-of-ai-infrastructure.html |
| [T04-S038] | India’s Yotta Bets $12B on 80,000 Nvidia Rubin GPUs | https://shattered.io/yotta-nvidia-vera-rubin-gpus-india-12-billion-2026 |
| [T04-S040] | Nvidia's Rubin GPUs hit the brakes as HBM4 memory drought threatens Jensen’s supply chain magic | https://www.sdxcentral.com/news/nvidias-rubin-gpus-hit-the-brakes-as-hbm4-memory-drought-threatens-jensens-supply-chain-magic-report |
| [T04-S031] | Nvidia Earnings 2026: $81.6B Record Quarter | https://tech-insider.org/nvidia-earnings-81-billion-quarter-2026 |
| [T04-S032] | Nvidia Stock: Breaking Down Its Key Risk | https://www.tradingkey.com/analysis/stocks/us-stocks/261841725-us-stock-nvidia-nvda-gpu-2026-ai-tpu-nasdaq-tradingkey |
| [T04-S033] | Nvidia’s dependence on hyperscalers faces big test in earnings report | https://www.cnbc.com/2026/08/25/nvidias-dependence-on-hyperscalers-faces-big-test-in-earnings-report.html |

## B.5 财务与技术依赖

| Source ID | 标题 | URL |
|---|---|---|
| [T05-S053] | NVIDIA Announces Financial Results for Fourth Quarter and Fiscal 2026 | https://investor.nvidia.com/news/press-release-details/2026/NVIDIA-Announces-Financial-Results-for-Fourth-Quarter-and-Fiscal-2026 |
| [T05-S055] | NVIDIA Announces Financial Results for Fourth Quarter and Fiscal 2026 (PDF) | https://nvidianews.nvidia.com/_gallery/download_pdf/699f6ab43d6332ccaa689907 |
| [T05-S007] | NVIDIA (NVDA) Grows Revenue by 65% in Fiscal 2026 | https://finance.yahoo.com/news/nvidia-nvda-grows-revenue-65-210604882.html |
| [T05-S052] | NVIDIA Announces Financial Results for First Quarter Fiscal 2027 | https://investor.nvidia.com/news/press-release-details/2026/NVIDIA-Announces-Financial-Results-for-First-Quarter-Fiscal-2027/default.aspx |
| [T05-S015] | What to Expect From NVIDIA's Q2 2027 Earnings Report | https://finance.yahoo.com/markets/stocks/articles/expect-nvidias-q2-2027-earnings-140406748.html |
| [T05-S016] | Nvidia Q2 FY2027 earnings: AI chip revenue doubles year over year | https://finance.yahoo.com/markets/stocks/articles/nvidia-q2-fy2027-earnings-revenue-210149949 |
| [T05-S018] | NVIDIA (NVDA) Tops Q2 Estimates and Guides Above Forecasts | https://finance.yahoo.com/markets/stocks/articles/nvidia-nvda-tops-q2-estimates-183248574.html |
| [T05-S046] | NVIDIA Corp. Balance Sheet | https://cn.stock-analysis-on.net/NASDAQ/%E5%85%AC%E5%8F%B8/NVIDIA-Corp/%E8%B4%A2%E5%8A%A1%E6%8A%A5%E5%91%8A/%E8%B5%84%E4%BA%A7%E8%B4%9F%E5%80%BA%E8%A1%A8%EF%BC%9A%E8%B4%9F%E5%80%BA%E5%92%8C%E8%82%A1%E4%B8%9C%E6%9D%83%E7%9B%8A |
| [T05-S017] | Nvidia fiscal Q2 2027 earnings outlook | https://www.investing.com/news/stock-market-news/nvidia-fiscal-q2-2027-earnings-outlook-what-to-watch-on-august-26-93CH-4872130 |
| [T05-S025] | 英伟达8月26日财报将披露客户集中度新数据 | https://www.readaitime.com/news/2026-08-25/1renzyac |
| [T05-S026] | NVIDIA连跌7个交易日：数据中心营收过度依赖大客户成业绩焦点 | https://www.digitaltoday.co.kr/cn/view/96578/nvidia-extends-seven-session-slide-hyperscaler-reliance-in-focus-ahead-of-results |
| [T05-S027] | 英伟达财报披露客户集中度引发担忧 两大客户贡献近四成营收 | https://www.cnbeta.com.tw/articles/tech/1521542.htm |
| [T05-S021] | 芯片博弈中的大国竞合：黄仁勋访华事件揭示全球AI | https://ciss.tsinghua.edu.cn/info/wzjx_mggc/9096 |
| [T05-S023] | 黄仁勋：英伟达正在“耐心等待”中国政府有关进口H200芯片的最终决定 | https://www.voachinese.com/a/nvidia-ceo-says-china-has-not-approved-h200-imports-20260129/8108022.html |
| [T05-S019] | 辉达的胜利：特朗普放行H200售予中国，但中国未必买单 | https://theinitium.com/20251210-whatsnew-trump-nvidia-sell-h200-china-zh-hans |
| [T05-S031] | CUDA生态护城河 | https://xueqiu.com/3405796236/363203819 |
| [T05-S032] | 70%毛利的秘密：CUDA，NVIDIA的「软件税」 | https://www.fomosoc.com/p/70cudanvidia-17nvda |
| [T05-S033] | 国产 GPU 生态适配：CUDA 兼容与全栈软件生态的建设进展 | https://www.starverse-ai.com/guide/archives/5095 |
| [T05-S036] | Anthropic 转向为 Claude 研发 AI 芯片 | https://www.tradingkey.com/zh-hans/analysis/stocks/us-stock/261772998-anthropic-moving-toward-ai-chips-claude-nvidia-buy-in-2026-tradingkey |
| [T05-S037] | AI芯天下丨深度丨AMD 92亿创纪录营收 | https://mp.ofweek.com/ee/a556714858567 |
| [T05-S038] | Rubin缩水背后，英伟达的CUDA神话正在松动 | https://wallstreetcn.com/articles/3775810 |
| [T05-S040] | 为什么全球所有大模型公司，都开始“背叛”英伟达？ | https://m.36kr.com/p/3889619812006533 |
| [T05-S041] | 下跌空间90%，英伟达：高估致命弱点未来2-3年 | https://caifuhao.eastmoney.com/news/20260912135008937338510 |
| [T05-S042] | 辉达、台积电靠边站？2026半导体惊人变局 | https://www.youtube.com/watch?v=LPByWbiduww |
| [T05-S043] | 台湾供应链突围与全球先进封装竞局 | https://www.ctimes.com.tw/DispArt/tw/CoWoS/HBM/%E5%85%88%E9%80%B2%E5%B0%81%E8%A3%9D/2509081821DI.shtml |
| [T05-S045] | 海外研选 | 大摩上调CoWoS需求预测 | https://www.cls.cn/detail/2409395 |