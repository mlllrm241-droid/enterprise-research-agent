from dotenv import load_dotenv

load_dotenv()

from app.core.model import get_model


def main():
    # =========================================
    # 1. 创建 MiMo
    # =========================================
    model = get_model()

    # =========================================
    # 2. 测试普通调用
    # =========================================
    response = model.invoke(
        "请只回答：MiMo连接成功"
    )

    # =========================================
    # 3. 输出结果
    # =========================================
    print(response.content)


if __name__ == "__main__":
    main()